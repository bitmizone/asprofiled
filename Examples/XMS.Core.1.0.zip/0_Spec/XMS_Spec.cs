using System;
using System.Collections;

namespace UWr.XMS.Base 
{
	#region XMS Specification
	[AttributeUsage( AttributeTargets.Method | AttributeTargets.Constructor | AttributeTargets.Property )]
	public class XMS_Spec : Attribute, IFormattable 
	{
		public int    LogicID;
		public string Precondition;
		public string Postcondition;
		public string Invariants;
		public string ModifiedParams;
		public string Proof;

		public XMS_Spec( 
			int LogicID, 
			string Precondition, 
			string Postcondition, 
			string Invariants, 
			string ModifiedParams,
			string Proof )
		{
			this.LogicID        = LogicID;
			this.Precondition   = Precondition;
			this.Postcondition  = Postcondition;
			this.Invariants     = Invariants;
			this.ModifiedParams = ModifiedParams;
			this.Proof          = Proof;
		}

        public XMS_Spec(
            string Precondition,
            string Postcondition,
            string Invariants )
            :
            this( 
                1, 
                Precondition, 
                Postcondition, 
                Invariants, 
                string.Empty, 
                string.Empty ) { }

		public override string ToString()
		{
			return string.Format( "{0}:\r\nPre=[{1}]\r\nPost=[{2}]\r\nInvs=[{3}]\r\nModified params=[{4}]\r\nProof=[{5}]", 
				LogicID, Precondition, Postcondition, Invariants, ModifiedParams, Proof );
		}

        #region IFormattable Members

        public string ToString( string format, IFormatProvider formatProvider )
        {
            switch ( format )
            {
                case "t":
                    return string.Format( "\tPre=[{0}]\r\n\tPost=[{1}]\r\n\tInvs=[{2}]\r\n",
                        Precondition, Postcondition, Invariants );

                default :
                    return ToString();
            }
        }

        public string ToString( string format )
        {
            return ToString( format, null );
        }

        #endregion
    }
	#endregion
	
	#region Exception
	public class XMS_Exception : ApplicationException
	{
		public XMS_Exception() : base() {}
		public XMS_Exception( string Message ) : base( Message ) {}
	}
	#endregion
}