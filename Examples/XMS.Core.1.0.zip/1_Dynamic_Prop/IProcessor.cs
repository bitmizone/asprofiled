using System;
using System.Diagnostics;
using System.Collections;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;

namespace UWr.XMS.Dynamic
{
	public interface IProcessor
	{
		// preprocess message
		// varValues: contains method call parameters
		bool PreProcess( InterceptContext varValues );
		// preprocess message
		// varValuesOrg : contains method call parameters
		// varValues    : contains actucal parameter values (when 'ret' is executed)
		// retMsg       : contains return value 
		bool PostProcess( InterceptContext varValuesOrg, InterceptContext varValues, object retValue );
	}
}
