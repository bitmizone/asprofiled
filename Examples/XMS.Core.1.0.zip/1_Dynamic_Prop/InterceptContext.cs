using System;
using System.Collections;
using System.Runtime.Remoting.Messaging;
using System.Reflection; 

namespace UWr.XMS.Dynamic
{
	public class InterceptContext
	{
		public MethodBase MethodBase;
		public string     MethodName;
		public Hashtable  Values;

		private InterceptContext() {}
		public InterceptContext( IMethodCallMessage Source )
		{
			this.MethodBase = Source.MethodBase;
			this.MethodName = Source.MethodName;

			this.Values = new Hashtable();

			for ( int i=0; i<Source.ArgCount; i++ )
				Values.Add( Source.GetArgName( i ), Source.GetArg( i ) );
		}
	}
}
