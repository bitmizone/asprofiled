using System;
using System.Diagnostics;
using System.Collections;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;

namespace UWr.XMS.Dynamic
{
	public class InterceptSink : IMessageSink
	{
		private IMessageSink nextSink;

		public InterceptSink( IMessageSink nextSink )
		{
			this.nextSink = nextSink;
		}

		#region IMessageSink Members
		public IMessage SyncProcessMessage( IMessage msg )
		{						
			// preprocess
			IMethodCallMessage mcm      = msg as IMethodCallMessage;
			InterceptContext preContext = new InterceptContext( mcm );
			bool pre = this.PreProcess( preContext );
						
			// actual call
			IMessage                retm = nextSink.SyncProcessMessage(msg);
			IMethodReturnMessage     mrm = (retm as IMethodReturnMessage);
			InterceptContext postContext = new InterceptContext( msg as IMethodCallMessage );
			
			// postprocess
			bool post = this.PostProcess( preContext, postContext, mrm.ReturnValue );

			if ( !pre || !post )
			{
				Trace.WriteLine( string.Format( "Testing failed for method {0}.", mcm.MethodName ) );
			}
			
			return mrm;
		}

		public IMessageSink NextSink
		{
			get
			{
				return this.nextSink;
			}
		}

		public IMessageCtrl AsyncProcessMessage(IMessage msg, IMessageSink replySink)
		{
			IMessageCtrl rtnMsgCtrl = nextSink.AsyncProcessMessage(msg,replySink);
			return rtnMsgCtrl;
		}

		#endregion

		private bool PreProcess( InterceptContext preContext )
		{
			ProcessAttribute[] attrs = (ProcessAttribute[])preContext.MethodBase.GetCustomAttributes(typeof(ProcessAttribute), true);

			bool pre = true;
			for(int i=0;i<attrs.Length;i++)
				pre &= attrs[i].Processor.PreProcess( preContext );

			return pre;
		}

		private bool PostProcess( InterceptContext preContext, InterceptContext postContext, object retValue )
		{
			ProcessAttribute[] attrs = (ProcessAttribute[])postContext.MethodBase.GetCustomAttributes(typeof(ProcessAttribute),true);

			bool pre = true;
			for(int i=0;i<attrs.Length;i++)
				pre &= attrs[i].Processor.PostProcess( preContext, postContext, retValue );
			
			return pre;
		}
	}	
}
