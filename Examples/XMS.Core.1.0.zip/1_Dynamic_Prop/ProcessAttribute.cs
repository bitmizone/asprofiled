using System;
using System.Diagnostics;
using System.Collections;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;

namespace UWr.XMS.Dynamic
{
	[AttributeUsage(AttributeTargets.Constructor | AttributeTargets.Method | AttributeTargets.Property,AllowMultiple=true)]
	public class ProcessAttribute : Attribute
	{
		private IProcessor p;

		public ProcessAttribute( Type ProcessorType )
		{
			this.p = Activator.CreateInstance( ProcessorType ) as IProcessor;
			if(this.p == null)
				throw new ArgumentException( string.Format( "The type '{0}' does not implement interface IProcessor!", ProcessorType.Name ) );
		}

		public IProcessor Processor
		{
			get{ return p; }
		}
	}
}
