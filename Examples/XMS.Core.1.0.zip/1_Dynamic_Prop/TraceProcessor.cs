using System;
using System.Diagnostics;
using System.Collections;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;

namespace UWr.XMS.Dynamic
{
	public class TraceProcessor : IProcessor
	{
		public TraceProcessor() {}

		public bool PreProcess( InterceptContext varValues )
		{
			Trace.Write( varValues.MethodName );
			
			Trace.Write( "( " );
			foreach ( DictionaryEntry de in varValues.Values )
				Trace.Write( string.Format( "{0} {1}, ", de.Value.GetType().Name, de.Key ) );
			Trace.Write( ")" );

			Trace.Write( " [ " );
			foreach ( DictionaryEntry de in varValues.Values )
				Trace.Write( string.Format( "{0}={1}, ", de.Key, de.Value ) );
			Trace.Write( "]" );
			Trace.WriteLine(string.Empty);

			return true;
		}

		public bool PostProcess( InterceptContext varValuesOrg, InterceptContext varValues, object retValue )
		{
			Trace.WriteLine( string.Format( "retval [{0}]: {1}", retValue.GetType(), retValue ) );

			return true;
		}
	}
}