using System;
using System.Diagnostics;
using System.Collections;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;

namespace UWr.XMS.Dynamic
{
	[AttributeUsage(AttributeTargets.Class)]
	public class XMSInterceptAttribute : ContextAttribute
	{
		
		public XMSInterceptAttribute() : base("Intercept")
		{
		}

		public override void Freeze(Context newContext)
		{			
		}

		public override void GetPropertiesForNewContext(System.Runtime.Remoting.Activation.IConstructionCallMessage ctorMsg)
		{
			ctorMsg.ContextProperties.Add( new InterceptProperty() );
		}

		public override bool IsContextOK(Context ctx, System.Runtime.Remoting.Activation.IConstructionCallMessage ctorMsg)
		{
			InterceptProperty p = ctx.GetProperty("Intercept") as InterceptProperty;
			if(p == null)
				return false;
			return true;
		}

		public override bool IsNewContextOK(Context newCtx)
		{
			InterceptProperty p = newCtx.GetProperty("Intercept") as InterceptProperty;
			if(p == null)
				return false;
			return true;
		}		
	}
}
