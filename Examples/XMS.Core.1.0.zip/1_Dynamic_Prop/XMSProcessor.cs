using System;
using System.Diagnostics;
using System.Collections;
using System.Collections.Specialized;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;

using System.CodeDom;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.Text;

using UWr.XMS.Base;
using UWr.XMS.VCGen;
using UWr.XMS.VCGen.Parsing;

namespace UWr.XMS.Dynamic
{
	public class XMSProcessor : IProcessor
	{
		public XMSProcessor() {}

		#region IProcessor Members

		public bool PreProcess( InterceptContext varValues )
		{			
			Trace.WriteLine( string.Format( "\r\n-----------------------------\r\nPreprocessing {0}.{1}.", varValues.MethodBase.DeclaringType.Name, varValues.MethodName ) );

			XMS_Spec[] specs = (XMS_Spec[])varValues.MethodBase.GetCustomAttributes( typeof(XMS_Spec), true );
			if ( specs != null )
				foreach ( XMS_Spec spec in specs )
				{
					Trace.WriteLine( string.Format( "\tspecification:\r\n{0}", spec.ToString( "t" ) ) );
					try
					{						
						SymbExpr exp = SymbExpr.Parse( spec.Precondition );
						Trace.WriteLine( string.Format( "\r\nPrecondition : {0}", exp ) );						

						return EvaluateExpression( exp, varValues, varValues, null );
					}
					catch ( Exception ex )
					{
						Trace.WriteLine( string.Format( "\r\nSpecification parsing & evaluating failed.\r\n{0}\r\n{1}", ex.Message, ex.StackTrace ) );
					}
				}			

			return true;
		}

		public bool PostProcess( InterceptContext varValuesOrg, InterceptContext varValues, object retValue )
		{
			XMS_Spec[] specs = (XMS_Spec[])varValues.MethodBase.GetCustomAttributes( typeof(XMS_Spec), true );
			if ( specs != null )
				foreach ( XMS_Spec spec in specs )
				{
					try
					{						
						SymbExpr exp = SymbExpr.Parse( spec.Postcondition );
						Trace.WriteLine( string.Format( "\r\nPostcondition : {0}", exp ) );						

						return EvaluateExpression( exp, varValuesOrg, varValues, retValue );
					}
					catch ( Exception ex )
					{
						Trace.WriteLine( string.Format( "\r\nSpecification parsing & evaluating failed.\r\n{0}\r\n{1}", ex.Message, ex.StackTrace ) );
					}
				}			

			return true;
		}
		#endregion

		#region Expression evaluator
		private bool EvaluateExpression( SymbExpr exp, InterceptContext varValuesOrg, InterceptContext varValues, object retValue )
		{
			// try to subst array refs & notnulls
			exp = EvalArraysAndNotNulls( exp, varValuesOrg, varValues, retValue );

			// try to subst free variables
			foreach ( string fv in exp.FreeVars() )
			{
				ConstExpr val = new ConstExpr( ConstExpr.Parser, GetValue( fv, varValuesOrg, varValues, retValue ) );

				exp = exp.Substitute( fv, val );
			}

			Trace.WriteLine( string.Format( "\tSubstituted expression : {0}", exp ) );
						
			// evaluate resulting predicate
			bool result = (bool)Evaluate( typeof(bool), exp.ToString() );

			Trace.WriteLine( string.Format( "\tEvaluated expression : {0}", result ) );

			return result;
		}

		public static object Evaluate( Type type, string expression )
		{
			ICodeCompiler comp = (new CSharpCodeProvider().CreateCompiler());
			CompilerParameters cp = new CompilerParameters();
			cp.ReferencedAssemblies.Add("system.dll");
			cp.GenerateExecutable = false;
			cp.GenerateInMemory = true;

			StringBuilder code = new StringBuilder();
			code.Append("using System; \n");
			code.Append("namespace _Evaluator { \n");
			code.Append("  public class _Evaluator { \n");
			code.AppendFormat("    public {0} Foo() ", type.Name );
			code.Append("{ ");
			code.AppendFormat("      return ({0}); ", expression);
			code.Append("}\n");
			code.Append("} }");

			CompilerResults cr = 
				comp.CompileAssemblyFromSource(cp, code.ToString());

			if (cr.Errors.HasErrors)
			{
				StringBuilder error = new StringBuilder();
				error.Append("Error Compiling Expression: ");
				foreach (CompilerError err in cr.Errors)
				{
					error.AppendFormat("{0}\n", err.ErrorText);
				}
				throw new Exception("Error Compiling Expression: " + 
					error.ToString());
			}
			Assembly    a = cr.CompiledAssembly;
			object      c = a.CreateInstance("_Evaluator._Evaluator");
			MethodInfo mi = c.GetType().GetMethod("Foo");
			return mi.Invoke( c, null );
		}
		
		#region Subst arrays & notnulls
		private SymbExpr EvalArraysAndNotNulls( SymbExpr exp, InterceptContext varValuesOrg, InterceptContext varValues, object ret )
		{
			switch ( exp.ExpType )
			{
				case SymbExpr.ExprType.NotNull :
					object v = GetValue( EvalArraysAndNotNulls( exp.NotNullExpr.ex, varValuesOrg, varValues, ret ).ToString(), varValuesOrg, varValues, ret );
					return v != null ? new ConstExpr( SymbExpr.Parser, true ) : new ConstExpr( SymbExpr.Parser, false );
				case SymbExpr.ExprType.Arr :
					Array     ar = (Array)GetValue( exp.ArrExpr.Name, varValuesOrg, varValues, ret );
					ConstExpr indexe = (ConstExpr)EvalArraysAndNotNulls( exp.ArrExpr.ex, varValuesOrg, varValues, ret );
					return new ConstExpr( SymbExpr.Parser, 
						ar.GetValue( (int)indexe.ConstExpr.val ) );
				case SymbExpr.ExprType.Bin :
					return new BinExpr( SymbExpr.Parser,
						EvalArraysAndNotNulls( exp.BinExpr.ex1, varValuesOrg, varValues, ret ),
						EvalArraysAndNotNulls( exp.BinExpr.ex2, varValuesOrg, varValues, ret ),
						exp.BinExpr.op );
				case SymbExpr.ExprType.Br :
					return new BrExpr( SymbExpr.Parser,
						EvalArraysAndNotNulls( exp.BrExpr.ex, varValuesOrg, varValues, ret ) );
				case SymbExpr.ExprType.Exists :
					return new ExistsExpr( SymbExpr.Parser,
						exp.ExistsExpr.n,
						EvalArraysAndNotNulls( exp.ExistsExpr, varValuesOrg, varValues, ret ) );
				case SymbExpr.ExprType.Forall : 
					return new ForallExpr( SymbExpr.Parser,
						exp.ForallExpr.n,
						EvalArraysAndNotNulls( exp.ForallExpr, varValuesOrg, varValues, ret ) );
				case SymbExpr.ExprType.Name :
                    object val = GetValue( exp.NameExpr.Name, varValuesOrg, varValues, ret );
                    return SymbExpr.Parse( val.ToString() );
				case SymbExpr.ExprType.Const :
					return exp;
				default : 
					throw new Exception( "Matching non-exhaustive in EvalSubTree!" );
			}
		}
		#endregion

		private object GetValue( string name, InterceptContext varValuesOrg, InterceptContext varValues, object ret )
		{
            // const?
            SymbExpr ce = SymbExpr.Parse( name );
            if ( ce is ConstExpr )
                return ce.ConstExpr.val;

			// possible values to look up			
			Hashtable hV = new Hashtable();

			// old values
			foreach ( DictionaryEntry de in varValuesOrg.Values )
			{
				string oname = XMS_Helper.GetOldNameFromName( (string)de.Key );
				if ( !hV.ContainsKey( oname ) )
					hV.Add( oname, de.Value );
			}
			// new values
			foreach ( DictionaryEntry de in varValues.Values )
			{
				string oname = (string)de.Key;
				if ( !hV.ContainsKey( oname ) )
					hV.Add( oname, de.Value );
			}
			// return value
			if ( ret != null )
				hV.Add( XMS_Helper.VALUE, ret );

			string[] nameparts = XMS_Helper.SplitName( name );					
			foreach ( string possiblevalue in hV.Keys )
			{
				if ( possiblevalue == nameparts[0] )
				{
                    if ( nameparts.Length == 1 )
                        return hV[possiblevalue];
                    else
                    {
                        // array?
                        if ( nameparts[1] == "[" )
                        {
                            string[] indexArray = (string[])XMS_Helper.CreateSubArray( nameparts, 2, nameparts.Length-3 );

                            Array  arrayRef   = (Array)GetValue( nameparts[0], varValuesOrg, varValues, ret );
                            int    indexValue = (int)GetValue( XMS_Helper.JoinName( indexArray ), varValuesOrg, varValues, ret );

                            return arrayRef.GetValue( indexValue );
                        }
                        else
                            // object reference
                            return GetObjectValue( nameparts, 1, hV[possiblevalue] );
                    }
				}
			}
			
			// return the same object
			return name;
		}

		/// <summary>
		/// Gets a value specified by nameparts from object value.
		/// 
		/// Eg. 
		/// 
		/// value == a 
		/// typeof(value) == ArrayList
		/// nameparts == [a, Length]
		/// index == 1
		/// 
		/// Returns: value of "a.Length"
		/// </summary>
		/// <param name="nameparts"></param>
		/// <param name="value"></param>
		/// <returns></returns>
		private object GetObjectValue( string[] nameparts, int index, object value )
		{
			Type valueType = value.GetType();

			MemberInfo[] fi = valueType.GetMember( nameparts[index] );
			if ( fi.Length > 0 )
			{
				object fv = null;

				if ( fi[0] is FieldInfo ) fv = ((FieldInfo)fi[0]).GetValue( value );
				if ( fi[0] is PropertyInfo ) fv = ((PropertyInfo)fi[0]).GetValue( value, null );

				if ( fv != null )
				{
					// last one?
					if ( index == nameparts.Length-1 )
						return fv;
					else
						return GetObjectValue( nameparts, index+1, fv );				 
				}
				
				throw new ApplicationException( string.Format( "Member {0} of type {1} is not a Field nor a Property!", nameparts[index], value.GetType() ) );
			}

			throw new ApplicationException( string.Format( "No member {0} found in type {1} in GetObjectValue!", nameparts[index], value.GetType() ) );
		}
		#endregion
	}
}
