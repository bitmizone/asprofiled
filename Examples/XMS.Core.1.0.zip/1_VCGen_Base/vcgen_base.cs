using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;

using UWr.XMS.Base;
using UWr.XMS.ILReader;

namespace UWr.XMS.VCGen
{
	#region XMS Helper
	public class XMS_Helper
	{
		public const string VALUE      = "VALUE";
		public const string THIS       = "this";
		public const string VARPREFIX  = "V_";
		public const string OLDPOSTFIX = "_ORIGINAL";

		public static bool IsNameAnOldName( string vname )
		{
			return vname.EndsWith( OLDPOSTFIX );
		}

		public static string GetNameFromOldName( string vname )
		{
			if ( IsNameAnOldName( vname ) )
				return vname.Substring( 0, vname.LastIndexOf( OLDPOSTFIX ) );
			else
				return vname;
		}

		public static string GetOldNameFromName( string vname )
		{
			if ( !IsNameAnOldName( vname ) )
				return string.Format( "{0}{1}", vname, OLDPOSTFIX );
			else
				return vname;
		}

        public static string[] SplitName( string Name )
        {
            List<string> ret = new List<string>();

            string[] parts = Name.Split( '.' );

            foreach ( string part in parts )
            {
                if ( part.IndexOf( "[" ) >= 0 &&
                     part.IndexOf( "]" ) >= 1
                    )
                {
                    if ( part.IndexOf( "[" ) > 0 )
                        ret.Add( part.Substring( 0, part.IndexOf( "[" ) ) );
                    ret.Add( "[" );
                    ret.AddRange( SplitName( part.Substring( part.IndexOf( "[" ) + 1, part.LastIndexOf( "]" ) - part.IndexOf( "[" ) - 1 ) ) );
                    ret.Add( "]" );
                }
                else
                    ret.Add( part );
            }

            return ret.ToArray();
        }

        public static string JoinName( string[] Parts )
        {
            StringBuilder sb = new StringBuilder();
            string prevpart = null;
            foreach ( string part in Parts )
            {
                if ( sb.Length > 0 &&
                     part != "[" && part != "]" &&
                     prevpart != "["
                    )
                    sb.Append( "." );

                sb.Append( part );
                prevpart = part;
            }

            return sb.ToString();
        }

        public static Array CreateSubArray( Array array, int Length )
        {
            return CreateSubArray( array, 0, Length );
        }

        public static Array CreateSubArray( Array array, int Offset, int Length )
        {
            Array ret = Array.CreateInstance( array.GetType().GetElementType(), Length );
            for ( int i = Offset; i < Offset + Length; i++ )
                ret.SetValue( array.GetValue( i ), i - Offset );

            return ret;
        }
	}
	#endregion

	#region Predicate
	public class Predicate
	{
		public string Formula;
		ArrayList trace = new ArrayList();
		public string Trace
		{
			get
			{
				StringBuilder sb = new StringBuilder();

				sb.Append( "[" );
				foreach ( int i in trace )
					sb.AppendFormat( "{0},", i );
				if ( sb.Length > 1 ) sb.Remove( sb.Length-1, 1 );
				sb.Append( "]" );

				return sb.ToString();
			}
		}

		public Predicate() {}
		public Predicate( string Formula ) { this.Formula = Formula; }

		public void AddTraceInstruction( int instruction )
		{
			trace.Add( instruction );
		}

		public override string ToString()
		{
			return string.Format( "{0}: {1}", Trace, Formula );
		}
	}
	#endregion

	#region Interfaces: IVCGen
	public interface IVerificationConditionGenerator
	{
		int         VCID { get; }

		Predicate   VCMethod( MethodBase methodBase );				
		Predicate[] VCMethodWithTraces( MethodBase methodBase );				
	}
	#endregion

	#region VCGenBase
	public class VCGenBase 
	{
		#region VCMethod
		public static string VCMethodBase( MethodBase methodBase )
		{
			MethodBodyReader mr = new MethodBodyReader( methodBase );

			if ( methodBase == null )
				return string.Empty;
			else
				return Dump( mr );
		}

        static string Dump( MethodBodyReader methodBody )
		{
            return methodBody.GetBodyCode();
		}
		#endregion

		#region Method specification
		public static XMS_Spec GetMethodSpecification( MethodBase methodBase, IVerificationConditionGenerator vcGen )
		{
			foreach ( object o in methodBase.GetCustomAttributes(true) )
				if ( o is XMS_Spec ) 				
					if ( ((XMS_Spec)o).LogicID == vcGen.VCID )
						return (XMS_Spec)o;
        
			return null;
		}
		#endregion
	}
	#endregion
}

