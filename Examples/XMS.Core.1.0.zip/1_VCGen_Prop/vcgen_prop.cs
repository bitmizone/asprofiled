using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using System.Text.RegularExpressions;

using Tools;
using UWr.XMS.Base;
using UWr.XMS.ILReader;
using UWr.XMS.VCGen.Lexing;
using UWr.XMS.VCGen.Parsing;

namespace UWr.XMS.VCGen
{
	#region Verification Condition Generator for Contracts 
	public class VCGen_Prop : IVerificationConditionGenerator
	{
		#region Exceptions
		private class NonIL0Exception : Exception
		{
			OpCode opCode;
			public OpCode OpCode
			{
				get { return opCode; }
			}
			public NonIL0Exception( OpCode opCode )
			{
				this.opCode = opCode;
			}
		}
		private class IllegalBackJumpException : Exception
		{
			int srcIns, destIns;
			public int SourceInstruction 
			{
				get { return srcIns; }
			}
			public int DestInstruction 
			{
				get { return destIns; }
			}
			public IllegalBackJumpException( int srcIns, int destIns )
			{
				this.srcIns  = srcIns;
				this.destIns = destIns;
			}
		}
		#endregion
		#region Invariant builder
		/// <summary>
		/// Get a hash with invariants for instructions
		/// </summary>
		private Hashtable CreateInvariantTable( SymbolicStore symb_store, XMS_Spec xms_spec )
		{
			Hashtable hRet = new Hashtable();
						
			// invariants
			if ( xms_spec.Invariants.Length > 0 )
			{
				string[] invs = xms_spec.Invariants.Split( ';' );
				int[] ins     = BackwardJumps( symb_store );
				
				if ( invs.Length != ins.Length )
					throw new XMS_Exception( string.Format( "Wrong number of invariants for method.\r\nFound {0} invariants and {1} targets for invariants.", invs.Length, ins.Length ) );			
				
				// modified variables of invariants
				for ( int i=0; i<ins.Length; i++ )
					hRet.Add( ins[i], new Invariant( ins[i], invs[i] ) );
			}
						
			return hRet;			
		}
		/// <summary>
		/// Returns a list of instructions that are targets for backward jumps
		/// </summary>
		private int[] BackwardJumps( SymbolicStore symb_store )
		{
			string[] jumps = { "br",   "brtrue",   "brfalse",   "bgt",   "blt",   "bge",   "ble",
								 "br.s", "brtrue.s", "brfalse.s", "bgt.s", "blt.s", "bge.s", "ble.s"				
							 };
			
			ArrayList aRet = new ArrayList();
			
			int i_no = 0;
			foreach ( ILInstruction i in symb_store.Reader.Instructions )
			{
				if ( Array.IndexOf( jumps, i.Code.Name )>=0 )
				{
					int target = symb_store.GetInstructionForOffset( (int)i.Operand );
					if ( target <= i_no &&
						!aRet.Contains( target ) 
						) 
						aRet.Add( target );
				}
				i_no++;
			}
			aRet.Sort();
						
			int[] retV = new int[aRet.Count];
			aRet.CopyTo( retV );
			
			return retV;
		}
		#endregion
        #region Evaluation entry point, Interface IVCGen,
        public int VCID
		{ 
			get
			{
				return 1;
			}
		}

		public Predicate[] VCMethodWithTraces( MethodBase methodBase )
		{
			return null;
		}

		public Predicate VCMethod( MethodBase methodBase )
		{
			XMS_Spec xms_spec = VCGenBase.GetMethodSpecification( methodBase, this );

			if ( xms_spec != null )
			{
                #region Trace
                Trace.WriteLine( string.Format( "\r\n\r\nMethod: {0}\r\n", methodBase ) );
                Trace.WriteLine( string.Format( "\t[{0}]\r\n", xms_spec.ToString().Replace( "\r\n", "," ) ) );
                #endregion

				try
				{
					MethodBodyReader reader = new MethodBodyReader( methodBase );
					SymbolicStore symb_store = new SymbolicStore( methodBase, reader );
					
					// build the invariant table
					symb_store.invTable = CreateInvariantTable( symb_store, xms_spec );

                    SymbExpr vcpred = SymbExpr.Parse(
                                        string.Format( "{0} => {1}",
                                                                    xms_spec.Precondition,
                                                                    SymbolicEvaluator( 0, symb_store, xms_spec ) ) );
	
				    vcpred = vcpred.Closure;
										
					return new Predicate( vcpred.ToString() );
				}
				catch ( IllegalBackJumpException ex )
				{
					throw new Exception( string.Format( "Backward jump ({0}-{1}) without an invariant found in {2}!", ex.SourceInstruction, ex.DestInstruction, methodBase.Name ), ex );
				}
				catch ( NonIL0Exception ex )
				{
                    throw new Exception( string.Format( "Non IL0 opcode ({0}) found in {1}!", ex.OpCode, methodBase.Name ), ex );
				}
			}

			return new Predicate( "True => True" );
		}
		#endregion
		#region Symbolic evaluator
		private string SymbolicEvaluator( 
			int curIns, 
			SymbolicStore symb_store,
			XMS_Spec xms_spec )
		{
			return SymbolicEvaluator( curIns, symb_store, xms_spec, true );
		}

        private string SymbolicEvaluator( 
			int curIns, 
			SymbolicStore symb_store,
			XMS_Spec xms_spec, 
			bool bLookForInv )
		{
			List<ILInstruction> instructions = symb_store.Reader.Instructions;

            #region Trace
            Trace.WriteLine( string.Empty );

            Trace.Write( "\targs:  " );
            foreach ( string Key in symb_store.symbArgs.Keys )
                Trace.Write( string.Format( "\t\t[{0}: {1}], ", Key, symb_store.symbArgs[Key] ) );

            Trace.Write( "\tvars:  " );
            foreach ( string Key in symb_store.symbVars.Keys )
                Trace.Write( string.Format( "\t\t[{0}: {1}], ", Key, symb_store.symbVars[Key] ) );

            Trace.Write( "\tstack: " );
            foreach ( object item in symb_store.symbStack )
                Trace.Write( string.Format( "\t\t[{0}] ", item ) );
            
            Trace.WriteLine( "\r\n" );
            Trace.WriteLine( string.Format( "-->{0}: {1} {2} [{3}]",
                instructions[curIns].Offset.ToString().PadLeft( 4, '0' ),
                instructions[curIns].Code,
                instructions[curIns].Operand,
                symb_store.GUID.ToString( "N" )
                ) );
            #endregion

            #region Invariant
            if ( bLookForInv && symb_store.invTable.ContainsKey( curIns ) )
			{
				// haven't we seen it before?
				if ( !symb_store.invContext.Contains( curIns ) )
				{		
					// no, this is the first time

					// sigma(Inv(i))
					StringBuilder sb = new StringBuilder();
					sb.Append( symb_store.Sigma( SymbExpr.Parse( ((Invariant)symb_store.invTable[ curIns ]).Predicate ) ).ToString() );
					sb.Append( " & " );

					// sigma' = sigma, L+(i)
					SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();
					symb_store_.invContext.Add( curIns );
					
					// forall...sigma'(Inv(i))
					Invariant    inv = (Invariant)symb_store.invTable[ curIns ];
					ArrayList aFresh = symb_store_.SetSymbolicValues( inv );
					foreach ( string key in aFresh )
						sb.AppendFormat( "forall {0}. ", key );
					sb.Append( symb_store_.Sigma( SymbExpr.Parse( ((Invariant)symb_store.invTable[ curIns ]).Predicate ) ).ToString() );

					sb.Append( "=>" );

					sb.Append( SymbolicEvaluator( curIns, symb_store_, xms_spec, false ) );

					return sb.ToString();
				}
				else
				{
					// check variables modified within the loop body
					Invariant i = (Invariant)symb_store.invTable[curIns];

					ArrayList mVars = symb_store.invContext.ModifiedVariables( curIns );
					if ( !ArrayListAsSet.Contains( i.ModifiedVariables, mVars ) )
						throw new ApplicationException( 
							string.Format( "Loop body does not declare modified variables properly at {0}!\r\nDeclared variables:({1})\r\nModified variables:({2})",
								curIns, ArrayListAsSet.ToString( i.ModifiedVariables ), ArrayListAsSet.ToString( mVars ) ) );

					// check stack modified within the loop body
					int mstack = symb_store.invContext.ModifiedStack( curIns );
					if ( mstack > i.ModifiedStack )
						throw new ApplicationException( 
							string.Format( "Loop body modifies {0} slots but declares {1} slots!", mstack, i.ModifiedStack ) );

					// return sigma(P)
					return symb_store.Sigma( SymbExpr.Parse( ((Invariant)symb_store.invTable[ curIns ]).Predicate ) ).ToString();
				}
			}
			#endregion

			#region Opcodes
			else
			{
				#region Arithmetical instructions

				#region ldc.i4
				if ( instructions[curIns].Code.Name == OpCodes.Ldc_I4.Name )
				{
					symb_store.symbStack.Push( new ConstExpr( SymbExpr.Parser, (int)instructions[curIns].Operand ) );
					symb_store.invContext.Current.IncreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
                if ( instructions[curIns].Code.Name == OpCodes.Ldc_I4_S.Name )
                {
                    symb_store.symbStack.Push( new ConstExpr( SymbExpr.Parser, (sbyte)instructions[curIns].Operand ) );
                    symb_store.invContext.Current.IncreaseStackDepth( 1 );

                    return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                }
                #endregion

				#region ldc.i4.i
				for ( int ldc=0; ldc<9; ldc++ )
					if ( instructions[curIns].Code.Name == string.Format( "{0}.{1}", OpCodes.Ldc_I4.Name, ldc ) )
					{
						symb_store.symbStack.Push( new ConstExpr( SymbExpr.Parser, ldc ) );
						symb_store.invContext.Current.IncreaseStackDepth(1);

						return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
					}
				#endregion

				#region ldc.r8
				if ( instructions[curIns].Code.Name == OpCodes.Ldc_R8.Name )
				{
					symb_store.symbStack.Push( new ConstExpr( SymbExpr.Parser, instructions[curIns].Operand ) );
					symb_store.invContext.Current.IncreaseStackDepth(1);
					
					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}				
				#endregion

                #region ldind
                if ( Array.IndexOf<string>( 
                     new string[] {
                         OpCodes.Ldind_I.Name, OpCodes.Ldind_I1.Name, OpCodes.Ldind_I2.Name, OpCodes.Ldind_I4.Name, OpCodes.Ldind_I8.Name,
                         OpCodes.Ldind_R4.Name, OpCodes.Ldind_R8.Name, OpCodes.Ldind_Ref.Name,
                         OpCodes.Ldind_U1.Name, OpCodes.Ldind_U2.Name, OpCodes.Ldind_U4.Name
                     },
                     instructions[curIns].Code.Name ) >=0 )
                {
                    SymbExpr addr = (SymbExpr)symb_store.symbStack.Pop();

                    if ( addr is IndExpr )
                    {
                        symb_store.symbStack.Push( ((IndExpr)addr).Value );

                        return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                    }
                    else
                        throw new XMS_Exception( "Ldind instruction is not called with IndExpr on stack!" );
                }				
                #endregion

                #region stind
                if ( Array.IndexOf<string>(
                     new string[] {
                         OpCodes.Stind_I.Name, OpCodes.Stind_I1.Name, OpCodes.Stind_I2.Name, OpCodes.Stind_I4.Name, OpCodes.Stind_I8.Name,
                         OpCodes.Stind_R4.Name, OpCodes.Stind_R8.Name, OpCodes.Stind_Ref.Name
                     },
                     instructions[curIns].Code.Name ) >= 0 )
                {
                    SymbExpr v    = (SymbExpr)symb_store.symbStack.Pop();
                    SymbExpr addr = (SymbExpr)symb_store.symbStack.Pop();

                    if ( addr is IndExpr )
                    {
                        ( (IndExpr)addr ).Value = v;

                        symb_store.invContext.Current.DecreaseStackDepth( 2 );

                        return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                    }
                    else
                        throw new XMS_Exception( "Stind instruction is not called with IndExpr on stack!" );
                }
                #endregion

                #region dup
                if ( instructions[curIns].Code.Name == OpCodes.Dup.Name )
				{
					SymbExpr u = (SymbExpr)symb_store.symbStack.Peek();
					symb_store.symbStack.Push( u );
					symb_store.invContext.Current.IncreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region pop
				if ( instructions[curIns].Code.Name == OpCodes.Pop.Name )
				{
					symb_store.symbStack.Pop();
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region add
				if ( instructions[curIns].Code.Name == OpCodes.Add.Name ) 
				{
					SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbStack.Push( new BinExpr( SymbExpr.Parser, u, v, "+" ) );
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region sub
				if ( instructions[curIns].Code.Name == OpCodes.Sub.Name ) 
				{
					SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbStack.Push( new BinExpr( SymbExpr.Parser, u, v, "-" ) );
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region mul
				if ( instructions[curIns].Code.Name == OpCodes.Mul.Name ) 
				{
					SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbStack.Push( new BinExpr( SymbExpr.Parser, u, v, "*" ) );
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region div
				if ( instructions[curIns].Code.Name == OpCodes.Div.Name ) 
				{
					SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbStack.Push( new BinExpr( SymbExpr.Parser, u, v, "/" ) );
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

                #region rem
                if ( instructions[curIns].Code.Name == OpCodes.Rem.Name )
                {
                    SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
                    SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
                    symb_store.symbStack.Push( new BinExpr( SymbExpr.Parser, u, v, "%" ) );
                    symb_store.invContext.Current.DecreaseStackDepth( 1 );

                    return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                }
                #endregion

				#region and
				if ( instructions[curIns].Code.Name == OpCodes.And.Name ) 
				{
					SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbStack.Push( new BinExpr( SymbExpr.Parser, u, v, "&" ) );
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region or
				if ( instructions[curIns].Code.Name == OpCodes.Or.Name ) 
				{
					SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbStack.Push( new BinExpr( SymbExpr.Parser, u, v, "|" ) );
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region xor
				if ( instructions[curIns].Code.Name == OpCodes.Xor.Name ) 
				{
					SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbStack.Push( new BinExpr( SymbExpr.Parser, u, v, "^" ) );
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region neg
				if ( instructions[curIns].Code.Name == OpCodes.Neg.Name ) 
				{
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbStack.Push( new UnExpr( SymbExpr.Parser, "-", u ) );
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region not
				if ( instructions[curIns].Code.Name == OpCodes.Not.Name ) 
				{
					SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbStack.Push( new UnExpr( SymbExpr.Parser, "!", v ) );
					symb_store.invContext.Current.DecreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

                #region conv
                if ( Array.IndexOf<string>( 
                     new string[] 
                     { OpCodes.Conv_I.Name, 
                       OpCodes.Conv_I1.Name, OpCodes.Conv_I2.Name, OpCodes.Conv_I4.Name, OpCodes.Conv_I8.Name,
                       OpCodes.Conv_Ovf_I.Name, OpCodes.Conv_Ovf_I_Un.Name, 
                       OpCodes.Conv_Ovf_I1.Name, OpCodes.Conv_Ovf_I1_Un.Name,
                       OpCodes.Conv_Ovf_I2.Name, OpCodes.Conv_Ovf_I2_Un.Name,
                       OpCodes.Conv_Ovf_I4.Name, OpCodes.Conv_Ovf_I4_Un.Name,
                       OpCodes.Conv_Ovf_I8.Name, OpCodes.Conv_Ovf_I8_Un.Name,
                       OpCodes.Conv_Ovf_U.Name, OpCodes.Conv_Ovf_U_Un.Name,
                       OpCodes.Conv_Ovf_U1.Name, OpCodes.Conv_Ovf_U1_Un.Name,
                       OpCodes.Conv_Ovf_U2.Name, OpCodes.Conv_Ovf_U2_Un.Name,
                       OpCodes.Conv_Ovf_U4.Name, OpCodes.Conv_Ovf_U4_Un.Name,
                       OpCodes.Conv_Ovf_U8.Name, OpCodes.Conv_Ovf_U8_Un.Name,
                       OpCodes.Conv_R_Un.Name, OpCodes.Conv_R4.Name, OpCodes.Conv_R8.Name,
                       OpCodes.Conv_U.Name, OpCodes.Conv_U1.Name, OpCodes.Conv_U2.Name, OpCodes.Conv_U4.Name, OpCodes.Conv_U8.Name
                     },
                     instructions[curIns].Code.Name )>=0 )
                {
                    return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                }
                #endregion

                #endregion

                #region Addressing fields and local variables

                #region ldarg, ldarga
                if ( instructions[curIns].Code.Name == OpCodes.Ldarg.Name ||
					 instructions[curIns].Code.Name == OpCodes.Ldarg_S.Name 
					)
				{
                    string vname = null;

                    // ldarg
                    if ( instructions[curIns].Operand is ParameterInfo )
					    vname = ((ParameterInfo)instructions[curIns].Operand).Name;
                    // ldarg.s
                    if ( instructions[curIns].Operand is byte )
                    {
                        int paramIndex = (byte)instructions[curIns].Operand;
                        // watch for default instance method parameter, "this"!
                        if ( !symb_store.MethodBase.IsStatic )
                            paramIndex--;

                        vname = symb_store.MethodBase.GetParameters()[paramIndex].Name;
                    }

					symb_store.symbStack.Push( symb_store.GetVariableValue( vname ) );
					symb_store.invContext.Current.IncreaseStackDepth(1);

//					symb_store.SetObjectName( vname );

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
                if ( instructions[curIns].Code.Name == OpCodes.Ldarga.Name ||
                     instructions[curIns].Code.Name == OpCodes.Ldarga_S.Name
                    )
                {
                    string vname = instructions[curIns].Operand.ToString();
                    symb_store.symbStack.Push( new IndExpr( SymbExpr.Parser, symb_store.GetVariableValue( vname ) ) );
                    symb_store.invContext.Current.IncreaseStackDepth( 1 );

                    return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                }
                #endregion

				#region ldarg.i
				for ( int ldarg = 0; ldarg<4; ldarg++ )
					if ( instructions[curIns].Code.Name == string.Format( "{0}.{1}", OpCodes.Ldarg.Name, ldarg ) ) 
					{
						string vname;
						if ( symb_store.MethodBase.IsStatic )
							vname = (symb_store.MethodBase.GetParameters()[ldarg]).Name;
						else
						{
							if ( ldarg != 0 )
								vname = (symb_store.MethodBase.GetParameters()[ldarg-1]).Name;
							else
								vname = XMS_Helper.THIS;
						}

						symb_store.symbStack.Push( symb_store.GetVariableValue( vname ) );
						symb_store.invContext.Current.IncreaseStackDepth(1);

//						symb_store.SetObjectName( vname );

						return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
					}
				#endregion

				#region starg
				if ( instructions[curIns].Code.Name == OpCodes.Starg.Name ||
					 instructions[curIns].Code.Name == OpCodes.Starg_S.Name 
					)
				{
                    string vname = null;

                    // starg
                    if ( instructions[curIns].Operand is ParameterInfo )
                        vname = ( (ParameterInfo)instructions[curIns].Operand ).Name;
                    // starg.s
                    if ( instructions[curIns].Operand is byte )
                    {
                        int paramIndex = (byte)instructions[curIns].Operand;
                        // watch for default instance method parameter, "this"!
                        if ( !symb_store.MethodBase.IsStatic )
                            paramIndex--;

                        vname = symb_store.MethodBase.GetParameters()[paramIndex].Name;
                    }
        
					if ( symb_store.symbArgs.ContainsKey( vname ) ) symb_store.symbArgs.Remove( vname );

//					symb_store.SetObjectName( vname );
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.symbArgs.Add( vname, u );

					symb_store.invContext.Current.DecreaseStackDepth(1);
					symb_store.invContext.Current.ModifiedVars.Add( vname );

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region starg.i
				for ( int starg = 0; starg<4; starg++ )
					if ( instructions[curIns].Code.Name == string.Format( "{0}.{1}", OpCodes.Starg.Name, starg ) ) 
					{
						string vname;
						if ( symb_store.MethodBase.IsStatic )
							vname = (symb_store.MethodBase.GetParameters()[starg]).Name;
						else
						{
							if ( starg != 0 )
								vname = (symb_store.MethodBase.GetParameters()[starg-1]).Name;
							else
								vname = XMS_Helper.THIS;
						}
	        
						if ( symb_store.symbArgs.ContainsKey( vname ) ) symb_store.symbArgs.Remove( vname );
						
//						symb_store.SetObjectName( vname );
						SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
						symb_store.symbArgs.Add( vname, u );

						symb_store.invContext.Current.DecreaseStackDepth(1);
						symb_store.invContext.Current.ModifiedVars.Add( vname );

						return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
					}
				#endregion

				#region ldloc
				if ( instructions[curIns].Code.Name == OpCodes.Ldloc.Name ||
					 instructions[curIns].Code.Name == OpCodes.Ldloc_S.Name 
					) 
				{   
					string vname = symb_store.CreateLocalVariableName( Convert.ToInt32( instructions[curIns].Operand ) );
					symb_store.symbStack.Push( symb_store.GetVariableValue( vname ) );
					symb_store.invContext.Current.IncreaseStackDepth(1);

					// set the name of symbolic object
//					symb_store.SetObjectName( vname );
					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region ldloc.i
				for ( int ldloc=0; ldloc<4; ldloc++ )
					if ( instructions[curIns].Code.Name == string.Format( "{0}.{1}", OpCodes.Ldloc.Name, ldloc ) ) 
					{   
						string vname = symb_store.CreateLocalVariableName( ldloc );
						symb_store.symbStack.Push( symb_store.GetVariableValue( vname ) );
						symb_store.invContext.Current.IncreaseStackDepth(1);

//						symb_store.SetObjectName( vname );
						return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
					}
				#endregion

				#region stloc
				if ( instructions[curIns].Code.Name == OpCodes.Stloc.Name ||
					 instructions[curIns].Code.Name == OpCodes.Stloc_S.Name 
					) 
				{
					string vname = symb_store.CreateLocalVariableName( Convert.ToInt32( instructions[curIns].Operand ) );
        
					if ( symb_store.symbVars.ContainsKey( vname ) ) symb_store.symbVars.Remove( vname );
					
//					symb_store.SetObjectName( vname );
					SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.invContext.Current.DecreaseStackDepth(1);
					symb_store.invContext.Current.ModifiedVars.Add( vname );

					// automatic type conversion for const expression
					if ( u.ExpType == SymbExpr.ExprType.Const )
					{
						Type destType = symb_store.Reader.MethodBody.LocalVariables[ Convert.ToInt32( instructions[curIns].Operand )].LocalType;
						u = new ConstExpr( SymbExpr.Parser, Convert.ChangeType( u.ConstExpr.val, destType ).ToString() );
					}
					symb_store.symbVars.Add( vname, u );

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region stloc.i
				for ( int stloc=0; stloc<4; stloc++ )
					if ( instructions[curIns].Code.Name == string.Format( "{0}.{1}", OpCodes.Stloc.Name, stloc ) ) 
					{
						string vname = symb_store.CreateLocalVariableName( stloc );
	        
						if ( symb_store.symbVars.ContainsKey( vname ) ) symb_store.symbVars.Remove( vname );

//						symb_store.SetObjectName( vname );
						SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
						symb_store.invContext.Current.DecreaseStackDepth(1);
						symb_store.invContext.Current.ModifiedVars.Add( vname );

						// automatic type conversion for const expression
						if ( u.ExpType == SymbExpr.ExprType.Const )
						{
							Type destType = symb_store.Reader.MethodBody.LocalVariables[ stloc ].LocalType;
							u = new ConstExpr( SymbExpr.Parser, Convert.ChangeType( u.ConstExpr.val, destType ).ToString() );
						}
						symb_store.symbVars.Add( vname, u );

						return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
					}
				#endregion

				#region ldfld, ldsfld
				if ( instructions[curIns].Code.Name == OpCodes.Ldfld.Name ) 
				{        
					// get fieldinfo and pop instance from the stack
					FieldInfo fi = (FieldInfo)instructions[curIns].Operand;
                    SymbExpr o = (SymbExpr)symb_store.symbStack.Pop();

					StringBuilder sb = new StringBuilder();
										
					// push the field value onto stack
					symb_store.symbStack.Push( o.GetField( fi.Name, fi.FieldType ) );
					symb_store.invContext.Current.IncreaseStackDepth(0);

//					symb_store.SetObjectName( string.Format( "{0}.{1}", o.Name, fi.Name ) );
					
					sb.Append( SymbolicEvaluator( curIns+1, symb_store, xms_spec ) );
					
					return sb.ToString();
				}
                if ( instructions[curIns].Code.Name == OpCodes.Ldsfld.Name )
                {
                    // get fieldinfo and pop instance from the stack
                    FieldInfo fi = (FieldInfo)instructions[curIns].Operand;

                    // push the field value onto stack
                    symb_store.symbStack.Push( symb_store.GetStaticField( fi ) );

                    symb_store.invContext.Current.IncreaseStackDepth( 0 );

                    return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                }
                #endregion

				#region stfld, stsfld
				if ( instructions[curIns].Code.Name == OpCodes.Stfld.Name ) 
				{
					// get fieldinfo 
					FieldInfo     fi = (FieldInfo)instructions[curIns].Operand;

					// pop new value from stack and pop instance from the stack
					SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
                    SymbExpr o = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.invContext.Current.DecreaseStackDepth(2);
					symb_store.invContext.Current.ModifiedVars.Add( string.Format( "{0}.{1}", o.Name, fi.Name ) );

//					symb_store.SetObjectName( v, string.Format( "{0}.{1}", o.Name, fi.Name ) );
					
					// set new value
					o.SetField( fi.Name, v );

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}

                if ( instructions[curIns].Code.Name == OpCodes.Stsfld.Name )
                {
                    // get fieldinfo 
                    FieldInfo fi = (FieldInfo)instructions[curIns].Operand;

                    // pop new value from stack and pop instance from the stack
                    SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
                    symb_store.invContext.Current.DecreaseStackDepth( 1 );

                    // symb_store.invContext.Current.ModifiedVars.Add( string.Format( "{0}.{1}", o.Name, fi.Name ) );

                    // set new value
                    symb_store.SetStaticField( fi, v );

                    return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                }
				#endregion

				#endregion

				#region Control flow

				#region nop
				if ( instructions[curIns].Code.Name == OpCodes.Nop.Name )
					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );								
				#endregion

				#region br, br_s
				if ( instructions[curIns].Code.Name == OpCodes.Br.Name ||
					 instructions[curIns].Code.Name == OpCodes.Br_S.Name 
					)
				{
					int destIns = symb_store.GetInstructionForOffset( (int)instructions[curIns].Operand );
					if ( destIns > curIns || symb_store.invTable.ContainsKey( destIns ) )
						return SymbolicEvaluator( destIns, symb_store, xms_spec );
					else
						throw new IllegalBackJumpException( curIns, destIns );
				}
				#endregion

				#region btrue l, brtrue_s l
				// use a copy of symb_store in one of paths
				if ( instructions[curIns].Code.Name == OpCodes.Brtrue.Name ||
					 instructions[curIns].Code.Name == OpCodes.Brtrue_S.Name 
					)
				{
					int destIns = symb_store.GetInstructionForOffset( (int)instructions[curIns].Operand );
					if ( destIns > curIns || symb_store.invTable.ContainsKey( destIns ) )
					{
						SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
						symb_store.invContext.Current.DecreaseStackDepth(1);

						SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();
						return String.Format( "(({0}=0=>{1}) && ({0}!=0=>{2}))",
							symb_store.Sigma( v ), 
							SymbolicEvaluator( curIns+1, symb_store, xms_spec ),
							SymbolicEvaluator( destIns, symb_store_, xms_spec ) );
					}
					else
						throw new IllegalBackJumpException( curIns, destIns );
				}
				#endregion

				#region brfalse l, brfalse_s l
				// use a copy of symb_store in one of paths
				if ( instructions[curIns].Code.Name == OpCodes.Brfalse.Name ||
					 instructions[curIns].Code.Name == OpCodes.Brfalse_S.Name 
					)
				{
					int destIns = symb_store.GetInstructionForOffset( (int)instructions[curIns].Operand );
					if ( destIns > curIns || symb_store.invTable.ContainsKey( destIns ) )
					{
						SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
						symb_store.invContext.Current.DecreaseStackDepth(1);

						SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();
						return String.Format( "(({0}!=0 => {1}) && ({0}==0 => {2}))",
							symb_store.Sigma( v ), 
							SymbolicEvaluator( curIns+1, symb_store, xms_spec ),
							SymbolicEvaluator( destIns, symb_store_, xms_spec ) );
					}
					else
						throw new IllegalBackJumpException( curIns, destIns );
				}
				#endregion

				#region bne
				if ( instructions[curIns].Code.Name == OpCodes.Bne_Un.Name ||
					 instructions[curIns].Code.Name == OpCodes.Bne_Un_S.Name 
					)
				{
					int destIns = symb_store.GetInstructionForOffset( (int)instructions[curIns].Operand );
					if ( destIns > curIns || symb_store.invTable.ContainsKey( destIns ) )
					{
						SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
						SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
						symb_store.invContext.Current.DecreaseStackDepth(2);

						SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();
						return String.Format( "(({0}=={1} => {2}) && ({0}!={1} => {3}))",
							symb_store.Sigma( u ), symb_store.Sigma( v ), 
							SymbolicEvaluator( curIns+1, symb_store, xms_spec ),
							SymbolicEvaluator( destIns, symb_store_, xms_spec ) );
					}
					else
						throw new IllegalBackJumpException( curIns, destIns );
				}
				#endregion

				#region bgt l, blt l
				// use a copy of symb_store in one of paths
				if ( instructions[curIns].Code.Name == OpCodes.Bgt.Name ||
					 instructions[curIns].Code.Name == OpCodes.Bgt_S.Name 
					)
				{
					int destIns = symb_store.GetInstructionForOffset( (int)instructions[curIns].Operand );
					if ( destIns > curIns || symb_store.invTable.ContainsKey( destIns ) )
					{
						SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
						SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
						symb_store.invContext.Current.DecreaseStackDepth(2);

						SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();
						return String.Format( "(({0}<={1} => {2}) && ({0}>{1} => {3}))",
							symb_store.Sigma( u ), symb_store.Sigma( v ), 
							SymbolicEvaluator( curIns+1, symb_store, xms_spec ),
							SymbolicEvaluator( destIns, symb_store_, xms_spec ) );
					}
					else
						throw new IllegalBackJumpException( curIns, destIns );
				}
				if ( instructions[curIns].Code.Name == OpCodes.Blt.Name ||
					 instructions[curIns].Code.Name == OpCodes.Blt_S.Name 
					)
				{
					int destIns = symb_store.GetInstructionForOffset( (int)instructions[curIns].Operand );
					if ( destIns > curIns || symb_store.invTable.ContainsKey( destIns ) )
					{
						SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
						SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
						symb_store.invContext.Current.DecreaseStackDepth(2);

						SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();
						return String.Format( "(({0}>={1} => {2}) && ({0}<{1} => {3}))",
							symb_store.Sigma( u ), symb_store.Sigma( v ), 
							SymbolicEvaluator( curIns+1, symb_store, xms_spec ),
							SymbolicEvaluator( destIns, symb_store_, xms_spec ) );
					}
					else
						throw new IllegalBackJumpException( curIns, destIns );
				}
				#endregion

				#region bge l, ble l
				// use a copy of symb_store in one of paths
				if ( instructions[curIns].Code.Name == OpCodes.Bge.Name ||
					 instructions[curIns].Code.Name == OpCodes.Bge_S.Name 
					)
				{
					int destIns = symb_store.GetInstructionForOffset( (int)instructions[curIns].Operand );
					if ( destIns > curIns || symb_store.invTable.ContainsKey( destIns ) )
					{
						SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
						SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
						symb_store.invContext.Current.DecreaseStackDepth(2);

						SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();
						return String.Format( "(({0}<{1} => {2}) && ({0}>={1} => {3}))",
							symb_store.Sigma( u ), symb_store.Sigma( v ), 
							SymbolicEvaluator( curIns+1, symb_store, xms_spec ),
							SymbolicEvaluator( destIns, symb_store_, xms_spec ) );
					}
					else
						throw new IllegalBackJumpException( curIns, destIns );
				}
				if ( instructions[curIns].Code.Name == OpCodes.Ble.Name ||
					 instructions[curIns].Code.Name == OpCodes.Ble_S.Name 
					)
				{
					int destIns = symb_store.GetInstructionForOffset( (int)instructions[curIns].Operand );
					if ( destIns > curIns || symb_store.invTable.ContainsKey( destIns ) )
					{
						SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
						SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
						symb_store.invContext.Current.DecreaseStackDepth(2);

						SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();
						return String.Format( "(({0}>{1} => {2}) && ({0}<={1} => {3}))",
							symb_store.Sigma( u ), symb_store.Sigma( v ), 
							SymbolicEvaluator( curIns+1, symb_store, xms_spec ),
							SymbolicEvaluator( destIns, symb_store_, xms_spec ) );
					}
					else
						throw new IllegalBackJumpException( curIns, destIns );
				}
				#endregion

                #region ceq
                // use a copy of symb_store in one of paths
                if ( instructions[curIns].Code.Name == OpCodes.Ceq.Name )
                {
                    SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
                    SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
                    symb_store.invContext.Current.DecreaseStackDepth( 2 );

                    SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();

                    symb_store.symbStack.Push( new ConstExpr( SymbExpr.Parser, 1 ) );
                    string BranchEq = SymbolicEvaluator( curIns + 1, symb_store, xms_spec );

                    symb_store_.symbStack.Push( new ConstExpr( SymbExpr.Parser, 0 ) );
                    string BranchNeq = SymbolicEvaluator( curIns + 1, symb_store_, xms_spec );

                    return String.Format( "(({0}=={1} => {2}) && ({0}!={1} => {3}))",
                        symb_store.Sigma( u ), symb_store.Sigma( v ),
                        BranchEq, BranchNeq );
                }
                #endregion

                #region clt, cgt
                // use a copy of symb_store in one of paths
                if ( instructions[curIns].Code.Name == OpCodes.Clt.Name )
                {
                    SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
                    SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
                    symb_store.invContext.Current.DecreaseStackDepth( 2 );

                    SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();

                    symb_store.symbStack.Push( new ConstExpr( SymbExpr.Parser, 1 ) );
                    string BranchEq = SymbolicEvaluator( curIns + 1, symb_store, xms_spec );

                    symb_store_.symbStack.Push( new ConstExpr( SymbExpr.Parser, 0 ) );
                    string BranchNeq = SymbolicEvaluator( curIns + 1, symb_store_, xms_spec );

                    return String.Format( "(({0}<{1} => {2}) && ({0}>={1} => {3}))",
                        symb_store.Sigma( u ), symb_store.Sigma( v ),
                        BranchEq, BranchNeq );
                }
                // use a copy of symb_store in one of paths
                if ( instructions[curIns].Code.Name == OpCodes.Cgt.Name )
                {
                    SymbExpr v = (SymbExpr)symb_store.symbStack.Pop();
                    SymbExpr u = (SymbExpr)symb_store.symbStack.Pop();
                    symb_store.invContext.Current.DecreaseStackDepth( 2 );

                    SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();

                    symb_store.symbStack.Push( new ConstExpr( SymbExpr.Parser, 1 ) );
                    string BranchEq = SymbolicEvaluator( curIns + 1, symb_store, xms_spec );

                    symb_store_.symbStack.Push( new ConstExpr( SymbExpr.Parser, 0 ) );
                    string BranchNeq = SymbolicEvaluator( curIns + 1, symb_store_, xms_spec );

                    return String.Format( "(({0}>{1} => {2}) && ({0}<={1} => {3}))",
                        symb_store.Sigma( u ), symb_store.Sigma( v ),
                        BranchEq, BranchNeq );
                }
                #endregion

				#region ret
				if ( instructions[curIns].Code.Name == OpCodes.Ret.Name )
				{		
					ArrayList mod = symb_store.invContext.ModifiedVariables(0);

					SymbExpr retPostCond;					
					retPostCond = SymbExpr.Parse( xms_spec.Postcondition );

					if ( symb_store.MethodBase is MethodInfo &&
						((MethodInfo)symb_store.MethodBase).ReturnType != typeof(void) ) 					
					{
						SymbExpr retV = (SymbExpr)symb_store.symbStack.Pop();
						// substitute with VALUE
						retPostCond = retPostCond.Substitute( XMS_Helper.VALUE, retV );
					}
					retPostCond = symb_store.Sigma( retPostCond, true );
					return retPostCond.ToString();
				}
				#endregion

				#endregion

				#region Calling methods

				#region call, callvirt
				if ( instructions[curIns].Code.Name == OpCodes.Call.Name ||
					 instructions[curIns].Code.Name == OpCodes.Callvirt.Name 
					)
				{
					// look for specification
					MethodBase m_called = (MethodBase)instructions[curIns].Operand;
					XMS_Spec m_spec = VCGenBase.GetMethodSpecification( m_called, this );

					if ( m_spec != null )
					{
						SymbolicStore sigma_g = new SymbolicStore( m_called, null ); 

						// consume stack parameters 
						ParameterInfo[]           parameters = m_called.GetParameters();
						SymbExpr[] symb_parameters = new SymbExpr[parameters.Length];
						for ( int p=0; p<symb_parameters.Length; p++ )
							symb_parameters[p] = (SymbExpr)symb_store.symbStack.Pop();						
						symb_store.invContext.Current.DecreaseStackDepth(symb_parameters.Length);


						// pass parameters
						sigma_g.symbArgs.Clear();
						for ( int p=0; p<parameters.Length; p++ )
							sigma_g.symbArgs.Add( parameters[p].Name, symb_parameters[p] );

						// instance parameter
						if ( !m_called.IsStatic )
						{
							sigma_g.symbArgs.Add( XMS_Helper.THIS, (SymbExpr)symb_store.symbStack.Pop() );						
							symb_store.invContext.Current.DecreaseStackDepth(1);
						}

						// is this a method and the method returns a value?
						if ( m_called is MethodInfo &&
							 ((MethodInfo)m_called).ReturnType == typeof(void) )
						{
							SymbExpr pre_g  = sigma_g.Sigma( SymbExpr.Parse( m_spec.Precondition ) );
							SymbExpr post_g = sigma_g.Sigma( SymbExpr.Parse( m_spec.Postcondition ) );

							return String.Format( "({0} && {1} => {2})",
								pre_g,
								post_g,
								SymbolicEvaluator( curIns+1, symb_store, xms_spec ) );
						}
						else
						{
							// push return value onto stack
							string retVal = 
                                m_called is MethodInfo ?
                                symb_store.CreateFreshName( ((MethodInfo)m_called).ReturnType.Name ) :
                                symb_store.CreateFreshName( m_called.Name );

							if ( m_called is MethodInfo &&
								((MethodInfo)m_called).ReturnType.IsValueType )
							{
								SymbExpr newNameExpr = new NameExpr( SymbExpr.Parser, retVal );
								symb_store.symbStack.Push( newNameExpr );
								sigma_g.symbArgs.Add( XMS_Helper.VALUE, newNameExpr );

								SymbExpr pre_g  = sigma_g.Sigma( SymbExpr.Parse( m_spec.Precondition ) );
								SymbExpr post_g = sigma_g.Sigma( SymbExpr.Parse( m_spec.Postcondition ) );

								return String.Format( "{0} & (forall {1}. {2} => {3})",
									pre_g,
									retVal, 
									post_g.Substitute( "VALUE", SymbExpr.Parse( retVal ) ),
									SymbolicEvaluator( curIns+1, symb_store, xms_spec ) );
							}
							else
							{
								SymbExpr newSymbObj = new SymbObj( SymbExpr.Parser, retVal );
								symb_store.symbStack.Push( newSymbObj );
								sigma_g.symbArgs.Add( XMS_Helper.VALUE, newSymbObj );

								SymbExpr pre_g  = sigma_g.Sigma( SymbExpr.Parse( m_spec.Precondition ) );
								SymbExpr post_g = sigma_g.Sigma( SymbExpr.Parse( m_spec.Postcondition ) );

								return String.Format( "({0} && {1} => {2})",
									pre_g,
									post_g,
									SymbolicEvaluator( curIns+1, symb_store, xms_spec ) );
							}
						}
					}
					else
					{
						// there is no specification
						// does the method return a value?
						if ( m_called is MethodInfo &&
							 ((MethodInfo)m_called).ReturnType == typeof(void) )
						{
							return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
						}
						else
						{
							// push return value onto stack
                            string retVal =
                                m_called is MethodInfo ?
                                symb_store.CreateFreshName( ( (MethodInfo)m_called ).ReturnType.Name ) :
                                symb_store.CreateFreshName( m_called.Name );

							if ( m_called is MethodInfo &&
								((MethodInfo)m_called).ReturnType.IsValueType )
							{
								symb_store.symbStack.Push( new NameExpr( SymbExpr.Parser, retVal ) );
								return String.Format( "(forall {0}. {1})",
									retVal, 
									SymbolicEvaluator( curIns+1, symb_store, xms_spec ) );
							}
							else
								return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
						}
					}
				}
				#endregion

				#endregion

				#region Creating objects

				#region ldnull
				if ( instructions[curIns].Code.Name == OpCodes.Ldnull.Name )
				{	
					symb_store.symbStack.Push( SymbObj.Null );
					symb_store.invContext.Current.IncreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region ldstr
				if ( instructions[curIns].Code.Name == OpCodes.Ldstr.Name )
				{	
					string s = (string)instructions[curIns].Operand;
					symb_store.symbStack.Push( new ConstExpr( SymbExpr.Parser, string.Format( "\"{0}\"", s ) ) );
					symb_store.invContext.Current.IncreaseStackDepth(1);

					return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#region newobj
				if ( instructions[curIns].Code.Name == OpCodes.Newobj.Name )
				{	
					ConstructorInfo c_called = (ConstructorInfo)instructions[curIns].Operand;

					// consume stack parameters
					ParameterInfo[] parameters = c_called.GetParameters();
					SymbExpr[] symb_parameters = new SymbExpr[parameters.Length];
					for ( int p=0; p<symb_parameters.Length; p++ )
						symb_parameters[p] = (SymbExpr)symb_store.symbStack.Pop();
					symb_store.invContext.Current.DecreaseStackDepth(symb_parameters.Length);

					// push new object onto stack
					// add it to the local object stock (for substitution)
                    SymbObj newObj = new SymbObj( SymbExpr.Parser, null, c_called.DeclaringType, symb_store.CreateFreshName( c_called.DeclaringType.FullName ) );
					symb_store.symbStack.Push( newObj );
					symb_store.invContext.Current.IncreaseStackDepth(1);

					symb_store.symbObjs.Add( newObj.Name, newObj );

					// look for specification
					XMS_Spec c_spec = VCGenBase.GetMethodSpecification( c_called, this );
					if ( c_spec != null )
					{
						SymbolicStore sigma_g = new SymbolicStore( c_called, null ); 
						
						// pass parameters
						sigma_g.symbArgs.Clear();
						for ( int p=0; p<parameters.Length; p++ )
							sigma_g.symbArgs.Add( parameters[p].Name, symb_parameters[p] );
						// instance parameter
						if ( !c_called.IsStatic )
							sigma_g.symbArgs.Add( XMS_Helper.THIS, newObj );

						string post_g = sigma_g.Sigma( SymbExpr.Parse( c_spec.Postcondition ) ).ToString();

						// constructor is always accessible?
						return String.Format( "({0} => {1})",
								post_g,
								SymbolicEvaluator( curIns+1, symb_store, xms_spec ) );
					}
					else
						return SymbolicEvaluator( curIns+1, symb_store, xms_spec );
				}
				#endregion

				#endregion

                #region Arrays
                if ( instructions[curIns].Code.Name == OpCodes.Newarr.Name )
                {
                    Type ArrayType = (Type)instructions[curIns].Operand;
 
                    SymbExpr length = (SymbExpr)symb_store.symbStack.Pop();                    
                    
                    ArrExpr arr = new ArrExpr( SymbExpr.Parser, symb_store.CreateFreshName( ArrayType.FullName ) );
                    arr.Length = length;

                    symb_store.symbArrs.Add( arr.Name, arr );

                    symb_store.symbStack.Push( arr );

                    return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                }

                if ( instructions[curIns].Code.Name == OpCodes.Ldlen.Name )
                {
                    ArrExpr array = (ArrExpr)symb_store.symbStack.Pop();
                    symb_store.symbStack.Push( array.Length );

                    return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                }

                if ( Array.IndexOf<string>( new string[]
                     { OpCodes.Stelem.Name, 
                       OpCodes.Stelem_I.Name, OpCodes.Stelem_I1.Name, OpCodes.Stelem_I2.Name, OpCodes.Stelem_I4.Name, OpCodes.Stelem_I8.Name, 
                       OpCodes.Stelem_R4.Name, OpCodes.Stelem_R8.Name, OpCodes.Stelem_Ref.Name },
                       instructions[curIns].Code.Name ) >= 0 
                    )
                {
                    // there are 3 cases for stelem
                    //
                    // case 1: there is no value stored in the symbolic array
                    // case 2: there is a value stored in the array that matches the queried index
                    // case 3: there are some values stored but none of them matches the queried index
                    //
                    // the last case is most complicated and is handled
                    // by generating conditional branches

                    SymbExpr expression = (SymbExpr)symb_store.symbStack.Pop();
                    SymbExpr index = (SymbExpr)symb_store.symbStack.Pop();
                    ArrExpr array = (ArrExpr)symb_store.symbStack.Peek();

                    // temporarily put again onto the stack to be able to clone the context
                    //symb_store.symbStack.Push( array );

                    if ( array.ValueCount == 0 || array.ContainsValue( index ) )
                    {
                        symb_store.symbStack.Pop();
                        array.AddValue( index, expression );

                        return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                    }
                    else
                    {
                        Dictionary<string, string> branches = new Dictionary<string, string>();

                        // branch for each Index from among symbolic indexes
                        foreach ( string existingIndex in new List<string>( array.Indexes ) )
                        {
                            SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone(); // clone 

                            array = (ArrExpr)symb_store_.symbStack.Pop();

                            /* merge values */
                            array.RemoveValue( existingIndex );
                            array.AddValue( index, expression );

                            branches.Add(
                                string.Format( "({0} == {1})", index, existingIndex ),
                                SymbolicEvaluator( curIns + 1, symb_store_, xms_spec ) );
                        }

                        // branch for actual Index that does not match any from above
                        // assumption: 
                        //   index != existingIndex1 && ... index != existingIndexK 
                        //   value => actual index
                        array = (ArrExpr)symb_store.symbStack.Pop();

                        array.AddValue( index, expression );

                        List<string> assumptions = new List<string>();
                        foreach ( string existingIndex in array.Indexes )
                            if ( existingIndex != index.ToString() ) 
                                assumptions.Add( string.Format( "({0} != {1})", index, existingIndex ) );
                        string assumption = string.Join( "&&", assumptions.ToArray() );

                        branches.Add( assumption, SymbolicEvaluator( curIns + 1, symb_store, xms_spec ) );

                        // all assumptions are built, return the predicate
                        List<string> allBranches = new List<string>();
                        foreach ( string asu in branches.Keys )
                            allBranches.Add( string.Format( "({0} => {1})", asu, branches[asu] ) );

                        return string.Join( "&&", allBranches.ToArray() );
                    }
                }

                if ( Array.IndexOf<string>( new string[]
                     { OpCodes.Ldelem.Name, 
                       OpCodes.Ldelem_I.Name, OpCodes.Ldelem_I1.Name, OpCodes.Ldelem_I2.Name, OpCodes.Ldelem_I4.Name, OpCodes.Ldelem_I8.Name, 
                       OpCodes.Ldelem_R4.Name, OpCodes.Ldelem_R8.Name, OpCodes.Ldelem_Ref.Name },
                       instructions[curIns].Code.Name ) >= 0
                    )
                {
                    // there are 3 cases for ldelem
                    //
                    // case 1: there is no value stored in the symbolic array
                    // case 2: there is a value stored in the array that matches the queried index
                    // case 3: there are some values stored but none of them matches the queried index
                    //
                    // the last case is most complicated and is handled
                    // by generating conditional branches

                    SymbExpr index = (SymbExpr)symb_store.symbStack.Pop();
                    ArrExpr  array = (ArrExpr)symb_store.symbStack.Pop();

                    if ( array.ValueCount == 0 || array.ContainsValue( index ) )
                    {
                        SymbExpr value = array.GetValue( index );
                        symb_store.symbStack.Push( value );

                        return SymbolicEvaluator( curIns + 1, symb_store, xms_spec );
                    }
                    else
                    {
                        Dictionary<string, string> branches = new Dictionary<string,string>();

                        // branch for each Index from among symbolic indexes
                        foreach ( string existingIndex in array.Indexes )
                        {
                            SymbolicStore symb_store_ = (SymbolicStore)symb_store.Clone();

                            SymbExpr value = array.GetValue( SymbExpr.Parse( existingIndex ) ).Clone();
                            symb_store_.symbStack.Push( value );

                            branches.Add(
                                string.Format( "({0} == {1})", index, existingIndex ),
                                SymbolicEvaluator( curIns + 1, symb_store_, xms_spec ) ); 
                        }

                        if ( !array.ContainsValue( index ) )
                        {
                            // branch for "fresh" Index that does not match any from above
                            // assumption: 
                            //   index != existingIndex1 && ... index != existingIndexK 
                            //   value => fresh value
                            SymbExpr fvalue = array.GetValue( index );
                            symb_store.symbStack.Push( fvalue );

                            List<string> assumptions = new List<string>();
                            foreach ( string existingIndex in array.Indexes )
                                assumptions.Add( string.Format( "({0} != {1})", index, existingIndex ) );
                            string assumption = string.Join( "&&", assumptions.ToArray() );

                            branches.Add( assumption, SymbolicEvaluator( curIns + 1, symb_store, xms_spec ) );
                        }

                        // all assumptions are built, return the predicate
                        List<string> allBranches = new List<string>();
                        foreach ( string asu in branches.Keys )
                            allBranches.Add( string.Format( "({0} => {1})", asu, branches[asu] ) );

                        return string.Join( "&&", allBranches.ToArray() );
                    }
                }
                #endregion

                throw new NonIL0Exception( instructions[curIns].Code );
			}
			#endregion
		}
		#endregion
	}
	#endregion

	#region Symbolic store
	class Invariant
	{
		public int    Instruction;
		public string Predicate;

		public int    ModifiedStack;
		public ArrayList ModifiedVariables = new ArrayList();
		
		private Invariant() {}
		public Invariant( int ins, string inv_data )
		{
            try
            {
			    string[] invm  = inv_data.Split(':');

			    this.Instruction = ins;								
			    this.Predicate = invm[0];
    		    this.ModifiedStack = int.Parse( invm[1] );
			    this.ModifiedVariables.AddRange( invm[2].Split(',') );
			}
			catch ( Exception ex )
            {
				throw new ApplicationException( string.Format( "Invariant format invalid: {0} Expected 'Pred:Stack:Vars'].", inv_data ), ex );
            }

		}
	
		public override string ToString()
		{
			return string.Format( "{0}: {1}", Instruction, Predicate );
		}
	}

	internal class SymbolicStore : ICloneable
	{
		#region Fields, properties
		private MethodBase methodBase;
        private MethodBodyReader reader;

		public Hashtable symbVars   = new Hashtable();
		public Hashtable symbArgs   = new Hashtable();
		
        public Hashtable symbObjs   = new Hashtable();
        public Hashtable symbArrs   = new Hashtable();

        public Hashtable symbStatic = new Hashtable();
		public Stack     symbStack  = new Stack();

        public Guid GUID = Guid.NewGuid();
				
		// invariant table and invariant context
		public Hashtable  invTable   = null;
		public StackSlots invContext = new StackSlots();

        public SymbolicStore( MethodBase methodBase, MethodBodyReader Reader )
		{
			this.methodBase = methodBase;
			this.reader     = Reader;

			SetDefaultValues();
		}

		public MethodBase MethodBase
		{
			get { return methodBase; }
		}
        public MethodBodyReader Reader
		{
			get { return reader; }
		}
		#endregion

        #region Helper methods
        public bool IsArgumentName( string Name )
        {
            ParameterInfo[] Params = MethodBase.GetParameters();

            for ( int i = 0; i < Params.Length; i++ )
                if ( Name == Params[i].Name )
                    return true;

            return false;
        }
        #endregion

        #region Symbolic values
        public void SetDefaultValues()
		{
			symbArgs.Clear();
			symbVars.Clear();
            symbStatic.Clear();

			// this argument
			SymbObj thisObj = new SymbObj( SymbExpr.Parser, XMS_Helper.THIS );
			if ( !methodBase.IsStatic )
				symbArgs.Add( XMS_Helper.THIS, thisObj );

			// method arguments
			foreach ( ParameterInfo pi in methodBase.GetParameters() )
			{
                if ( !pi.ParameterType.IsByRef )
                {
                    if ( pi.ParameterType.IsArray )
                        symbArgs.Add( pi.Name, new ArrExpr( SymbExpr.Parser, pi.Name ) );
                    else if ( pi.ParameterType.IsValueType )
                        symbArgs.Add( pi.Name, new NameExpr( SymbExpr.Parser, pi.Name ) );
                    else
                        symbArgs.Add( pi.Name, new SymbObj( SymbExpr.Parser, pi.Name ) );
                }
                else
                {
                    Type baseType = GetNonPointerType( pi.ParameterType );

                    if ( pi.ParameterType.IsArray )
                        symbArgs.Add( pi.Name, new ArrExpr( SymbExpr.Parser, pi.Name ) );
                    else if ( baseType.IsValueType )
                        symbArgs.Add( pi.Name, new IndExpr( SymbExpr.Parser, new NameExpr( SymbExpr.Parser, pi.Name ) ) );
                    else
                        symbArgs.Add( pi.Name, new IndExpr( SymbExpr.Parser, new SymbObj( SymbExpr.Parser, pi.Name ) ) );
                }
                // original value
                symbArgs.Add( XMS_Helper.GetOldNameFromName( pi.Name ), ( (SymbExpr)symbArgs[pi.Name] ).Clone() );
			}

			// default field values in constructor
			if ( methodBase is ConstructorInfo )
			{
				foreach ( FieldInfo fi in methodBase.DeclaringType.GetFields( BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static ) )
				{
					if ( fi.FieldType.IsValueType )
					{
						object defVal = Activator.CreateInstance( fi.FieldType );
						thisObj.SetField( fi.Name, new ConstExpr( SymbExpr.Parser, defVal ) );
					}
					else
						thisObj.SetField( fi.Name, SymbObj.Null );
				}
			}

			// method local variables
			if ( reader != null )
				for ( int i=0; i<reader.MethodBody.LocalVariables.Count; i++ )
				{
                    if ( !reader.MethodBody.LocalVariables[i].LocalType.IsPointer )
                    {
                        if ( reader.MethodBody.LocalVariables[i].LocalType.IsArray )
                        {
                            symbVars.Add( CreateLocalVariableName( i ), new ArrExpr( SymbExpr.Parser, CreateLocalVariableName( i ) ) );
                        }
                        else if ( reader.MethodBody.LocalVariables[i].LocalType.IsValueType )
                        {
                            object defVal = Activator.CreateInstance( reader.MethodBody.LocalVariables[i].LocalType );
                            symbVars.Add( CreateLocalVariableName( i ), new ConstExpr( SymbExpr.Parser, defVal ) );
                        }
                        else
                            symbVars.Add( CreateLocalVariableName( i ), new SymbObj( SymbExpr.Parser, CreateLocalVariableName( i ) ) );
                    }
                    else
                        symbVars.Add( CreateLocalVariableName( i ), new IndExpr( SymbExpr.Parser ) );
				}
		}

		/// <summary>
		/// Returns a list of freshed names
		/// </summary>
		public ArrayList SetSymbolicValues( Invariant inv )
		{
			ArrayList aFreshed = new ArrayList();
				
			// freshen stack values 
			// (at most inv.ModifiedStack but can be less if there are 
			//  less stack slots ocuppied)
			ArrayList aStack = new ArrayList();
			for ( int i=0; i<inv.ModifiedStack; i++ )
				if ( symbStack.Count > 0 )
					aFreshed.Add( symbStack.Pop() );
			for ( int i=aFreshed.Count-1; i>=0; i-- )
			{
				if ( aFreshed[i] is SymbObj )
				{
					string freshName = CreateFreshName( ((SymbObj)aFreshed[i]).Name );
					SymbObj freshObj = new SymbObj( SymbExpr.Parser, freshName );
					symbStack.Push( freshObj );
					symbObjs.Add( freshName, freshObj ); 
				}
				else
				{
					string  freshName = CreateFreshName( "stack" );
					SymbExpr freshObj = new NameExpr( SymbExpr.Parser, freshName );
					symbStack.Push( freshObj );
				}
			}

			// freshen method local variables
			foreach ( string v in inv.ModifiedVariables )
			{
				string freshValue = CreateFreshName( v );
						
				Type vType = GetVariableType( freshValue );
				if ( vType != null && vType.IsValueType )
					SetVariableValue( v, new NameExpr( SymbExpr.Parser, freshValue ) );
				else
					SetVariableValue( v, new SymbObj( SymbExpr.Parser, freshValue ) );
				aFreshed.Add( freshValue );
			}
					
			return aFreshed;
		}
		#endregion

		#region Helpers

        #region Obs�uga nazw p�l
        /// <summary>
        /// Create symbolic name for a local variable
        /// 
        /// k -> V_k
        /// 
        /// Example:
        /// 0 -> V_0, 1 -> V_1
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public string CreateLocalVariableName( int i )
        {
            return string.Format( "{0}{1}", XMS_Helper.VARPREFIX, i );
        }

        /// <summary>
        /// Full name for FieldInfo variable
        /// 
        /// Example: 
        /// Type: UWr.XMS.Type1, Field: AField
        /// 
        /// Returns: UWr.XMS.Type1.AField
        /// </summary>
        /// <param name="fi"></param>
        /// <returns></returns>
        private string CreateFullNameForFieldInfo( FieldInfo fi )
        {
            return string.Format( "{0}.{1}", fi.DeclaringType.FullName, fi.Name );
        }
        #endregion

        #region Tworzenie �wie�ych nazw i odzyskiwanie oryginalnych
        /// <summary>
		/// Returns a fresh name in given context
		/// </summary>
		/// <param name="basedUpon"></param>
		/// <returns></returns>
		internal Hashtable hFreshNames = new Hashtable();
		public string CreateFreshName( string basedUpon0 )
		{
			int _count = 0;
			string basedUpon = RestoreOriginalName( basedUpon0 );
			if ( hFreshNames.ContainsKey( basedUpon ) )
			{
				_count = (int)hFreshNames[basedUpon];
				hFreshNames.Remove(basedUpon);
			}

			hFreshNames.Add( basedUpon, ++_count );

			StringBuilder sb = new StringBuilder();
			
            sb.Append( basedUpon );
            sb.Append( "__" );
            sb.Append( _count );

			//for ( int i=0; i<_count; i++ )
			//	sb.Append( "_" );

			return sb.ToString();
		}

        /// <summary>
        /// Reversal of the CreateFreshName() method, 
        /// rebuils the original name for given fresh name
        /// </summary>
        /// <param name="varBase"></param>
        /// <returns></returns>
		public string RestoreOriginalName( string Name )
		{
            //string[] parts  = Name.Split( '.' );
            string[] parts = XMS_Helper.SplitName( Name );
            List<string> nparts = new List<string>();

            foreach ( string part in parts )
            {
                string npart = part;

                // search for '__' at the end
                int indexof__ = part.LastIndexOf( "__" );
                if ( indexof__ >= 0 )
                {
                    string ending = part.Substring( indexof__ + 2 );
                    int res;
                    if ( int.TryParse( ending, out res ) )
                        npart = part.Substring( 0, indexof__ );
                }
                nparts.Add( npart );
            }

            // return string.Join( ".", nparts.ToArray() );
            return XMS_Helper.JoinName( nparts.ToArray() );
        }

        #endregion

        #region Full info for given name
        /// <summary>
        /// Determine type and value of given literal name.
        /// 
        /// Possibilities:
        /// 
        /// this
        /// this.pole
        /// VALUE
        /// VALUE.pole
        /// nazwaobiektu.pole
        /// nazwaobiektu_.pole
        /// 
        /// Example:
        /// 
        /// Name: Object_.AField
        /// 
        /// Expected output:
        /// 
        /// VarName: Object_
        /// Type:    type of( Object_ )
        /// Value:   value of( Object_ )
        /// </summary>
        public void GetVariableInfo( 
            string       Name, 
            out   string VariableName,
            out     Type VariableType,
            out SymbExpr VariableValue )
		{
            // default values
            VariableType  = null;
            VariableValue = null;
            VariableName  = string.Empty;

			// remove ending __
            string TypePrefix;
            string Index;
            SplitLiteral( Name, out TypePrefix, out VariableName, out Index );

            if ( VariableName == XMS_Helper.THIS )
            {
                VariableType = methodBase.DeclaringType;

                // pure this
                if ( Name == VariableName )
                    VariableValue = (SymbExpr)symbArgs[XMS_Helper.THIS];
            }

            if ( VariableName == XMS_Helper.VALUE &&                 
				 methodBase is MethodInfo 
				)
			{
				VariableType  = ((MethodInfo)methodBase).ReturnType;

                // pure value
                // if ( Name == VariableName )
                //   VariableValue = (SymbExpr)symbStack.Peek();
			}
            if ( VariableName.StartsWith( XMS_Helper.VARPREFIX ) )
			{
				// local variable
                int varNo = int.Parse( VariableName.Substring( 2 ) );
                
                VariableType  = reader.MethodBody.LocalVariables[varNo].LocalType;
                VariableValue = (SymbExpr)symbVars[VariableName];
			}
            // no success up to this point?
            if ( VariableType == null || VariableValue == null )
			{
				// method's parameter (or zero value)
                foreach ( ParameterInfo pi in methodBase.GetParameters() )
                {
                    /* parameter */
                    if ( VariableName == pi.Name )
                    {
                        VariableType = pi.ParameterType;

                        if ( Name == VariableName )
                            VariableValue = (SymbExpr)symbArgs[VariableName];
                    }
                    else
                    /* zero value */
                    if ( XMS_Helper.GetNameFromOldName( VariableName ) == pi.Name )
                    {
                        VariableType = pi.ParameterType;

                        VariableValue = (SymbExpr)symbArgs[VariableName];
                    }
                }
           
                // static name [!indexed by full name!]
                if ( symbStatic.ContainsKey( Name ) )
                {
                    Type baseType = this.MethodBase.Module.GetType( TypePrefix );
                    MemberInfo[] mi = baseType.GetMember( VariableName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static );
                    if ( mi != null && mi.Length > 0 )
                    {
                        if ( mi[0] is FieldInfo )
                            VariableType = ( (FieldInfo)mi[0] ).FieldType;
                        if ( mi[0] is PropertyInfo )
                            VariableType = ( (PropertyInfo)mi[0] ).PropertyType;
                    }
                    VariableValue = (SymbExpr)symbStatic[Name];
                }

                // local array
                if ( symbArrs.ContainsKey( VariableName ) )
                {
                    VariableValue = (ArrExpr)symbArrs[VariableName];
                    VariableType = Type.GetType( RestoreOriginalName( VariableName ) ).MakeArrayType();
                }

                // still no luck? 
                // compound name [recursion]
                if ( VariableValue == null &&
                     Name.IndexOf( "." ) >= 0 )                     
                {
                    if ( VariableType == null )
                        VariableType = methodBase.Module.GetType( TypePrefix );

                    SymbExpr objectValue;
                    
                    // try to get symbolic value
                    // 
                    // 1th - from symbObjs
                    // 2nd - recursion
                    if ( symbObjs.ContainsKey( VariableName ) )
                        objectValue = (SymbObj)symbObjs[VariableName];
                    else 
                    if ( symbArrs.ContainsKey( VariableName ) )
                        objectValue = (ArrExpr)symbArrs[VariableName];
                    else
                        objectValue = GetVariableValue( VariableName );

                    Type TypeOfValue = VariableType;
                    if ( Name != VariableName )
                    {
                        // indexed name, resolve the index
                        if ( Index != null &&
                             objectValue is ArrExpr
                            )
                        {
                            SymbExpr IndexExpr = SymbExpr.Parse( Index );
                            while ( !( IndexExpr is NameExpr ) &&
                                    !( IndexExpr is ConstExpr )
                                   )
                                IndexExpr = GetVariableValue( IndexExpr.ToString() );

                            objectValue = objectValue.ArrExpr.GetValue( IndexExpr );
                            // remove the index
                            Name = Name.Replace( string.Format( "[{0}]", Index ), string.Empty );

                        }

                        // get object value
                        VariableValue = GetObjectValue( Name, VariableName, objectValue, VariableType, out TypeOfValue );
                    }
                    else
                        VariableValue = objectValue;
                    VariableType = TypeOfValue;
                }

                // variable[Index]
                if ( Index != null &&
                     Name == string.Format( "{0}[{1}]", VariableName, Index )
                    )
                {
                    SymbExpr arr = GetVariableValue( VariableName );
                    if ( arr is ArrExpr )
                        VariableValue = arr.ArrExpr.GetValue( SymbExpr.Parse( Index ) );
                }
			}
            
            // default
            if ( VariableValue == null )
                VariableValue = new NameExpr( SymbExpr.Parser, Name );
		}

        /// <summary>
        /// Determine which part of given literal carries
        /// - type name
        /// - variable name
        /// - field references
        /// 
        /// Examples:
        /// 
        /// Input:
        /// Namespace.Subnamespace.Class.Field
        /// 
        /// Output:
        /// Typename: Namespace.Subnamespace.Class
        /// Variable: Field
        /// 
        /// Input:
        /// Namespace.Subnamespace.Class__2.Field
        /// 
        /// Output:
        /// Typename: Namespace.Subnamespace.Class
        /// Variable: Namespace.Subnamespace.Class__2
        ///         
        /// Input:
        /// Namespace.Subnamespace.Class__2[TheIndex].Field
        /// 
        /// Output:
        /// Typename: Namespace.Subnamespace.Class
        /// Variable: Namespace.Subnamespace.Class__2
        /// Index   : TheIndex 
        /// </summary>
        /// <param name="Name"></param>
        /// <returns></returns>
        public void SplitLiteral( string Name, out string TypeName, out string Variable, out string Index )
        {
            Index = null; 

            //string[] parto = Name.Split( '.' );
            //string[] parts = RestoreOriginalName( Name ).Split( '.' );
            string[] parto = XMS_Helper.SplitName( Name );
            string[] parts = XMS_Helper.SplitName( RestoreOriginalName( Name ) );

            // zmienna lokalna, obiekt THIS, warto�� VALUE
            if ( parts[0].StartsWith( XMS_Helper.VARPREFIX ) ||
                 parts[0] == XMS_Helper.THIS ||
                 parts[0] == XMS_Helper.VALUE
                )
            {
                TypeName = XMS_Helper.THIS;
                Variable = parts[0];

                return;
            }
            // argument
            if ( symbArgs.ContainsKey( Name ) )
            {
                TypeName = null;
                Variable = Name;

                return;
            }

            // Singleton: name of called method or constructor
            if ( parts.Length == 1 )
            {
                TypeName = null;
                Variable = parts[0];

                return;
            }
            else
            {
                // a compound name
                //
                // possibilities:
                //  
                // 1th: Argument_name.FieldName
                // 2nd: Namespace.Subnamespace.Typename.Variable.FieldName
                // 2th b: Type.Name[Index] (array newed inside the method) (for example System.Int32[i]
                // 3rd: Namespace.Subnamespace.Typename.StaticField / StaticProperty
                string sbparto = null;
                string sbparts = null;
                for ( int index = 0; index<parts.Length; index++ )
                {
                    // append
                    /*
                    if ( sbparts.Length > 0 && !( sbparts[sbparts.Length - 1] == '.' ) )
                        sbparts.Append( '.' );
                    sbparts.Append( parts[index] );

                    if ( sbparto.Length > 0 && !( sbparto[sbparto.Length - 1] == '.' ) )
                        sbparto.Append( '.' );
                    sbparto.Append( parto[index] );
                     */
                    sbparts = XMS_Helper.JoinName( (string[])XMS_Helper.CreateSubArray( parts, index + 1 ) );
                    sbparto = XMS_Helper.JoinName( (string[])XMS_Helper.CreateSubArray( parto, index + 1 ) );

                    // 1th
                    if ( symbArgs.ContainsKey( sbparts ) )
                    {
                        TypeName = null;
                        Variable = sbparts;

                        if ( Array.IndexOf( parts, "]" ) >= 0 )
                            Index = XMS_Helper.JoinName( (string[])XMS_Helper.CreateSubArray( parts, Array.IndexOf( parts, "[" ) + 1, Array.LastIndexOf( parts, "]" ) - Array.IndexOf( parts, "[" ) - 1 ) );

                        return;
                    }
                    // 2nd
                    try
                    {
                        if ( methodBase.Module.Assembly.GetType( sbparts ) != null ||
                             Type.GetType( sbparts ) != null 
                            )
                            if ( sbparts == sbparto )
                            {
                                TypeName = sbparts;
                                Variable =
                                    parts.Length >= index + 1 ?
                                    parts[index + 1] :
                                    null;

                                if ( Array.IndexOf( parts, "]" ) >= 0 )
                                    Index = XMS_Helper.JoinName( (string[])XMS_Helper.CreateSubArray( parts, Array.IndexOf( parts, "[" ) + 1, Array.LastIndexOf( parts, "]" ) - Array.IndexOf( parts, "[" ) - 1 ) );

                                return;
                            }
                            else
                            {
                                TypeName = sbparts;
                                Variable = sbparto;

                                if ( Array.IndexOf( parts, "]" ) >= 0 )
                                    Index = XMS_Helper.JoinName( (string[])XMS_Helper.CreateSubArray( parts, Array.IndexOf( parts, "[" ) + 1, Array.LastIndexOf( parts, "]" ) - Array.IndexOf( parts, "[" ) - 1 ) );

                                return;
                            }
                    }
                    catch { }
                }
            }

            throw new Exception( string.Format( "{0} is not a compound name or does not start with known type name.", Name ) );
        }
        #endregion
        
        #region Setting and getting values of variables

        public Type GetVariableType( string Name )
        {
            Type Type;
            string VarName;
            SymbExpr Value;

            GetVariableInfo( Name, out VarName, out Type, out Value );

            return Type;
        }

        public SymbExpr GetVariableValue( string Name )
        {
            Type     Type;
            string   VarName;
            SymbExpr Value;

            GetVariableInfo( Name, out VarName, out Type, out Value );

            return Value;
        }

        public void SetVariableValue( string v, SymbExpr e )
		{
			// the result depends on whether v 
			// v beeing a simple name or a qualified name
			if ( v.IndexOf( "." ) > 0 )
			{
				string varBase = v.Split( '.' )[0];
				SetObjectValue( v, GetVariableType( varBase ), (SymbObj)GetVariableValue( varBase ), e );
			}        
			else  
				if ( symbArgs.ContainsKey( v ) )
			{
				symbArgs.Remove( v );
				symbArgs.Add( v, e );
			}
			else
				if ( symbVars.ContainsKey( v ) )
			{
				symbVars.Remove( v );
				symbVars.Add( v, e );
			}	
			else
				if ( symbObjs.ContainsKey( v ) )
			{
				symbObjs.Remove( v );
				symbObjs.Add( v, e );
			}
		}

		public void SetObjectValue( string v, Type vType, SymbExpr o, SymbExpr e )
		{
			string[]      fields = v.Split( '.' );          
			FieldInfo childField = vType.GetField( fields[1], BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance );

			// recursion
			if ( fields.Length > 2 )
			{
                SymbExpr oc = o.GetField( fields[1], childField.FieldType );
				if ( childField != null && oc != null )
					SetObjectValue( v.Substring( v.IndexOf( "." )+1 ), childField.FieldType, oc, e );
				else
					throw new Exception( string.Format( "No type or value was found for field {0} in GetObjectValue!", fields[0] ) );
			}
			else
				o.SetField( fields[1], e );
        }

        /// <summary>
        /// This method returns the value of a compound expression.
        /// 
        /// Case 1:
        /// 
        /// Name         : Compound reference, ex. h.n
        /// Variable name: Name prefix that denotes the variable, ex. h
        /// ParentType   : Type of variable, ex. h.GetType()
        /// 
        /// Examples:
        /// 
        /// Name   : h.n
        /// VarName: h
        /// ParType: typeof(Uwr.XMS.Tests.HelperClass1)
        /// 
        /// Name   : "Uwr.XMS.Tests.HelperClass1__1.n"
        /// VarName: "Uwr.XMS.Tests.HelperClass1__1"
        /// ParType: typeof(Uwr.XMS.Tests.HelperClass1)
        /// 
        /// Name   : "Uwr.XMS.Tests.HelperClass1__2.child.n"
        /// VarName: "Uwr.XMS.Tests.HelperClass1__2"
        /// ParType: typeof(Uwr.XMS.Tests.HelperClass1)
        /// 
        /// Case 2:
        /// 
        /// Name         : Compound reference, ex. Namespace.Subnamespace.Type.StaticField / Property, ex. Uwr.Tests.Tests_2.property1
        /// VariableName : Name suffix that denotes the member, ex. property1
        /// ParentType   : Type of the member, ex. property1.GetType()
        /// </summary>
        /// <param name="Name"></param>
        /// <param name="VariableName"></param>
        /// <param name="symbObject"></param>
        /// <param name="ParentType"></param>
        /// <param name="TypeOfValue"></param>
        /// <returns></returns>
        public SymbExpr GetObjectValue( string Name, string VariableName, SymbExpr symbObject, Type ParentType, out Type TypeOfValue )
        {
            string[] fields = null;

            // Split
            if ( Name.StartsWith( VariableName ) )
                fields = XMS_Helper.SplitName( Name.Substring( VariableName.Length + 1 ) );
            if ( Name.EndsWith( VariableName ) )
                // Special case where VariableName == symbObject.Name
                if ( VariableName == symbObject.Name )
                {
                    TypeOfValue = ParentType;
                    return symbObject;
                }
                else
                    fields = Name.Substring( Name.Length - VariableName.Length ).Split( '.' );

            if ( fields == null )
                throw new Exception( string.Format( "Cannot get object value [Name: {0}, VariableName: {1}", Name, VariableName ) );

            FieldInfo childField = ParentType.GetField( fields[0], BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance );
            PropertyInfo childProp = ParentType.GetProperty( fields[0], BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance );

            if ( childField == null && childProp == null )
                throw new XMS_Exception( string.Format( "Member {0} of type {1} does denote neither a field nor a property.", fields[0], ParentType.Name ) );

            TypeOfValue =
                childField != null ? childField.FieldType : childProp.PropertyType;

            // recursion
            if ( fields.Length > 1 )
            {
                SymbExpr oc = symbObject.GetField( fields[0], TypeOfValue );

                if ( oc != null )
                    return GetObjectValue( string.Join( ".", fields ), fields[0], oc, childField.FieldType, out TypeOfValue );
                else
                    throw new Exception( string.Format( "No type or value was found for field {0} in GetObjectValue!", fields[0] ) );
            }
            else
                return symbObject.GetField( fields[0], TypeOfValue );
        }
        #endregion

        #region Static fields
        public SymbExpr GetStaticField( FieldInfo field )
        {
            if ( !symbStatic.Contains( CreateFullNameForFieldInfo( field ) ) )
                symbStatic.Add( CreateFullNameForFieldInfo( field ),
                    field.FieldType.IsValueType ?
                    (SymbExpr)( new NameExpr( SymbExpr.Parser, CreateFullNameForFieldInfo( field ) ) ) :
                    (SymbExpr)( new SymbObj( SymbExpr.Parser, CreateFullNameForFieldInfo( field ) ) ) );

            return (SymbExpr)symbStatic[CreateFullNameForFieldInfo( field )];
        }

        public void SetStaticField( FieldInfo field, SymbExpr value )
        {
            if ( symbStatic.ContainsKey( CreateFullNameForFieldInfo( field ) ) )
                symbStatic.Remove( CreateFullNameForFieldInfo( field ) );

            symbStatic.Add( CreateFullNameForFieldInfo( field ), value );
        }
        #endregion

        #region Other
        /// <summary>
		/// Returns the number of the instruction of given offset
		/// </summary>
		/// <param name="offset"></param>
		/// <returns></returns>
		public int GetInstructionForOffset( int offset )
		{
			List<ILInstruction> ins = reader.Instructions;
			for ( int i=0; i<ins.Count; i++ )
				if ( ins[i].Offset == offset )
					return i;

			throw new Exception( string.Format( "No instruction at offset {0} in {1}!", offset, methodBase.Name ) );
		}

        public Type GetNonPointerType( Type TypeToDeref )
        {
            if ( TypeToDeref.FullName.EndsWith( "&" ) )
            {
                return TypeToDeref.Module.GetType( TypeToDeref.FullName.Substring( 0, TypeToDeref.FullName.Length - 1 ) );
                //return Type.GetType( TypeToDeref.FullName.Substring( 0, TypeToDeref.FullName.Length - 1 ) );
            }
            else
                return TypeToDeref;
        }
        #endregion

        #endregion

        #region Sigma
        public SymbExpr Sigma0( SymbExpr exp )
		{
			// expression variables
			SymbExpr texp = exp;
			foreach ( string v in exp.Vars() )
			{
				texp = texp.Substitute( v, GetVariableValue( v ) );
			}

			return texp;
		}

        /// <summary>
        /// When the RET opcode is handled all changes made to local arguments are gone (IL semantics)
        /// so the call for value of an argument has to be redirected to the original value
        /// </summary>
        /// <param name="exp"></param>
        /// <param name="HandlingRetOpcode"></param>
        /// <returns></returns>
        public SymbExpr Sigma( SymbExpr exp, bool HandlingRetOpcode )
        {
            switch ( exp.ExpType )
            {
                case SymbExpr.ExprType.Arr:
                    SymbExpr val = GetVariableValue( exp.ArrExpr.Name );
                    if ( val is ArrExpr )
                        return ((ArrExpr)val).GetValue( Sigma( exp.ArrExpr.ex, HandlingRetOpcode ) );
                    else
                        throw new Exception( string.Format( "The [{0}] is not recognized as symbolic array!", exp.ArrExpr.Name ) );

                case SymbExpr.ExprType.Bin:
                    return new BinExpr( SymbExpr.Parser, Sigma( exp.BinExpr.ex1, HandlingRetOpcode ), Sigma( exp.BinExpr.ex2, HandlingRetOpcode ), exp.BinExpr.op );

                case SymbExpr.ExprType.Br :
                    return new BrExpr( SymbExpr.Parser, Sigma( exp.BrExpr.ex, HandlingRetOpcode ) );

                case SymbExpr.ExprType.Exists:
                    return new ExistsExpr( SymbExpr.Parser, GetVariableValue( exp.ExistsExpr.n ).ToString(), Sigma( exp.ExistsExpr.ex, HandlingRetOpcode ) );

                case SymbExpr.ExprType.Fn:
                    return new FnExpr( SymbExpr.Parser, Sigma( exp.FnExpr.f ), Sigma( exp.FnExpr.arg, HandlingRetOpcode ) );

                case SymbExpr.ExprType.Forall:
                    return new ForallExpr( SymbExpr.Parser, GetVariableValue( exp.ForallExpr.n ).ToString(), Sigma( exp.ForallExpr.ex, HandlingRetOpcode ) );

                case SymbExpr.ExprType.Ind:
                    return new IndExpr( SymbExpr.Parser, Sigma( exp.IndExpr.Value, HandlingRetOpcode ) );

                case SymbExpr.ExprType.Name :
                    if ( !IsArgumentName( exp.NameExpr.Name ) || !HandlingRetOpcode )
                        return GetVariableValue( exp.NameExpr.Name );
                    else
                        return GetVariableValue( XMS_Helper.GetOldNameFromName( exp.NameExpr.Name ) );

                case SymbExpr.ExprType.NotNull:
                    return new NotNullExpr( SymbExpr.Parser, Sigma( exp.NotNullExpr.ex ) );

                case SymbExpr.ExprType.Un:
                    return new UnExpr( SymbExpr.Parser, exp.UnExpr.op, Sigma( exp.UnExpr.ex ) );
                
                default :
                    return exp;
            }
        }

        public SymbExpr Sigma( SymbExpr exp )
        {
            return Sigma( exp, false );
        }
		#endregion

		#region ICloneable Members
        /// <summary>
        /// Cloning the symbolic context is not easy.
        /// 
        /// First - a deep copy of structures has to be done
        ///         (with cloning of every symbolic object)
        ///         because changes in object made in different context
        ///         has to be independent
        /// 
        /// However the is a subtle issue with symbolic objects 
        /// created with newobj. Since during invoke of newobject
        /// we do not know whether such object will be stored in 
        /// local variable or in a parameter, it gets the name
        /// derived from the object's type.
        /// 
        /// For example: 
        /// 
        /// void F()
        /// {
        ///   C c = new C();
        /// }
        /// 
        /// the object created here ultimately is assigned to c
        /// is it not known but when it is created.
        /// 
        /// Thus, in such symbolic context, the same physical object 
        /// exists both in symbObj (after it is created) and in
        /// symbVars (after it is stored in the local variable named c).
        /// 
        /// The same applies to objects copied from arguments to variables or,
        /// in general, from any collection to another.
        /// 
        /// And finally, cloning has to detect such objects, ie.
        /// it cannot clone such object twice, to two independent
        /// instances.
        /// </summary>
        /// <returns></returns>
		public object Clone()
		{
			SymbolicStore nS = new SymbolicStore( this.methodBase, this.reader );

            // deep copy here with equal reference detecting
            Hashtable Clones = new Hashtable();

            nS.symbArgs = CopyHashtable( this.symbArgs, Clones );
            nS.symbVars = CopyHashtable( this.symbVars, Clones );

            nS.symbObjs = CopyHashtable( this.symbObjs, Clones );
            nS.symbArrs = CopyHashtable( this.symbArrs, Clones );

            nS.symbStatic = CopyHashtable( this.symbStatic, Clones );
            nS.symbStack = CopyStack( this.symbStack, Clones );
				
            // shallow copy here
			nS.invTable   = (Hashtable)this.invTable.Clone();
			nS.invContext = (StackSlots)this.invContext.Clone();
            nS.hFreshNames = (Hashtable)this.hFreshNames.Clone();

			return nS;
		}

        #warning This will not work if two different objects have the same hash code [should not happen]
        private Hashtable CopyHashtable( Hashtable Source, Hashtable Clones )
        {
            Hashtable ret = new Hashtable();

            foreach ( object key in Source.Keys )
                if ( Clones.Contains( Source[key].GetHashCode() ) )
                    ret.Add( key, Clones[Source[key].GetHashCode()] );
                else
                {
                    SymbExpr clone = ( (SymbExpr)Source[key] ).Clone();

                    Clones.Add( Source[key].GetHashCode(), clone );
                    ret.Add( key, clone );
                }

            return ret;
        }

        private Stack CopyStack( Stack Source, Hashtable Clones )
        {
            ArrayList a = new ArrayList();
            foreach ( SymbExpr expr in Source )
                if ( Clones.Contains( expr.GetHashCode() ) )
                    a.Add( Clones[expr.GetHashCode()] );
                else
                {
                    SymbExpr clone = expr.Clone();

                    Clones.Add( expr.GetHashCode(), clone );
                    a.Add( clone );
                }
            a.Reverse();

            Stack ret = new Stack();
            foreach ( SymbExpr nexpr in a )
                ret.Push( nexpr );

            return ret;
        }
		#endregion

	}
	#endregion
	#region Stack slot
	class StackSlots : ICloneable
	{
		ArrayList slots = new ArrayList();

		public StackSlots()
		{
			Add( 0 );
		}

		public StackSlots( ArrayList slots )
		{
			this.slots = slots;
		}

		public void Add( int instruction )
		{
			slots.Add( new StackSlot( instruction ) );
		}

		public bool Contains( int instruction )
		{
			foreach ( StackSlot s in slots )
				if ( s.Instruction == instruction )
					return true;

			return false;
		}

		public StackSlot GetSlotAt( int instruction )
		{
			foreach ( StackSlot s in slots )
				if ( s.Instruction == instruction )
					return s;

			throw new Exception( string.Format( "No slot found at {0}!", instruction ) );
		}

		public StackSlot Current
		{
			get
			{
				return (StackSlot)slots[slots.Count-1];
			}
		}

		public int ModifiedStack( int instruction )
		{
			int ms = 0;

			for ( int s=0; s<slots.Count; s++ )
			{
				StackSlot ss = (StackSlot)slots[s];
				if ( ss.Instruction >= instruction )
					ms += ss.MinModifiedStack;
			}
				
			return ms;
		}

		public ArrayList ModifiedVariables( int instruction )
		{
			ArrayList aRet = new ArrayList();

			for ( int s=0; s<slots.Count; s++ )
			{
				StackSlot ss = (StackSlot)slots[s];
				if ( ss.Instruction >= instruction )
					foreach ( string var in ss.ModifiedVars )
						if ( !aRet.Contains( var ) )
							aRet.Add( var );
			}
				
			return aRet;
		}
		#region ICloneable Members
		public object Clone()
		{
			ArrayList newslots = new ArrayList();
			foreach ( StackSlot s in slots )
				newslots.Add( new StackSlot( s ) );
			return new StackSlots( newslots );
		}
		#endregion
	}

	internal class StackSlot
	{
		public ArrayList ModifiedVars;

		int m_instruction;
		public int Instruction
		{
			get
			{
				return m_instruction;
			}
		}

		public StackSlot( int instruction )
		{
			this.m_instruction = instruction;
			this.ModifiedVars  = new ArrayList();
		}

		public StackSlot( StackSlot src ) : this( src.Instruction )
		{
			foreach ( string v in src.ModifiedVars )
				this.ModifiedVars.Add( v );
		}

		int stackDepth;
		int maxstackDepth;
		int minstackDepth;
		public void DecreaseStackDepth( int depth )
		{
			stackDepth -= depth;
			if ( minstackDepth > stackDepth )
				minstackDepth = stackDepth;
		}
		public void IncreaseStackDepth( int depth )
		{
			stackDepth += depth;
			if ( maxstackDepth < stackDepth )
				maxstackDepth = stackDepth;
		}
		/// <summary>
		/// How many values were pushed onto the stack
		/// </summary>
		public int MaxModifiedStack
		{
			get
			{
				return maxstackDepth;
			}
		}
		/// <summary>
		/// How many values were popped from the stack
		/// </summary>
		public int MinModifiedStack
		{
			get
			{
				return Math.Abs( minstackDepth );
			}
		}
	}
	#endregion
	#region Set operations
	internal class ArrayListAsSet
	{
		public static ArrayList Union( ArrayList u, ArrayList v )
		{
			ArrayList aRet = new ArrayList( u );
				
			foreach( object item in v )
				if ( !aRet.Contains( item ) )
					aRet.Add( item );

			return aRet;
		}

		public static ArrayList Subtraction( ArrayList u, ArrayList v )
		{
			ArrayList aRet = new ArrayList();

			foreach ( object item in u )
				if ( !v.Contains( item ) )
					aRet.Add( item );

			return aRet;
		}

		public static bool Contains( ArrayList u, ArrayList v )
		{
			foreach ( object item in v )
				if ( !u.Contains( item ) )
					return false;

			return true;
		}

		public static bool Equals( ArrayList u, ArrayList v )
		{
			return Contains( u, v ) & Contains( v, u );
		}

		public static string ToString( ArrayList u )
		{
			StringBuilder sb = new StringBuilder();

			foreach ( object item in u )
				sb.AppendFormat( "{0} ,", item );
			if ( sb.Length>2 ) sb.Remove( sb.Length-2, 2 );

			return sb.ToString();
		}
	}
	#endregion
}
