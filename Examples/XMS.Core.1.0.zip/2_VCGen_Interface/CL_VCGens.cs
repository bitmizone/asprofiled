using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

using UWr.XMS.VCGen;

namespace UWr.XMS.VCGen.Interface
{
	public class CL_VCGens
	{
		public static ArrayList GetAvailableVCGens()
		{
			ArrayList aRet = new ArrayList();

			aRet.Add( new UWr.XMS.VCGen.VCGen_Prop() );

			return aRet;
		}

		public static ArrayList GetAvailableVCGens( string path )
		{    
			string[] fNames  = Directory.GetFiles( path, "*.dll" );
			ArrayList   aRes = new ArrayList();
			foreach ( string name in fNames )
			{
				try
				{
					Assembly assembly = Assembly.LoadFrom( name );
					foreach ( Type t in assembly.GetTypes() )
					{
						object o = Activator.CreateInstance( t );
						if ( o is IVerificationConditionGenerator )
							aRes.Add( o );
					}
				}
				catch  {}
			}

			return aRes;
		}
	}
}