// created on 2004-05-12 at 22:11
using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Text;

using UWr.XMS.Base;
using UWr.XMS.VCGen;

namespace UWr.XMS.VCGen.Interface 
{
	public class f_VCGenAssembly : System.Windows.Forms.Form
	{
		private Assembly assembly;

		private TreeView tvDrzewo;
		private Splitter sBelka;
		private Panel       pPrawo;
		private RichTextBox txtBody;
		private Splitter    sTexts;
		private RichTextBox txtBottom;

		ArrayList vcGens;

		public f_VCGenAssembly( Assembly assembly )
		{
			InitializeComponent();

			this.assembly = assembly;
			this.Text     = assembly.Location;

			InitializeData();
		}
		
		#region InitializeComponent
		void InitializeComponent() 
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(f_VCGenAssembly));
			this.pPrawo = new System.Windows.Forms.Panel();
			this.txtBody = new System.Windows.Forms.RichTextBox();
			this.sTexts = new System.Windows.Forms.Splitter();
			this.txtBottom = new System.Windows.Forms.RichTextBox();
			this.sBelka = new System.Windows.Forms.Splitter();
			this.tvDrzewo = new System.Windows.Forms.TreeView();
			this.pPrawo.SuspendLayout();
			this.SuspendLayout();
			// 
			// pPrawo
			// 
			this.pPrawo.Controls.Add(this.txtBody);
			this.pPrawo.Controls.Add(this.sTexts);
			this.pPrawo.Controls.Add(this.txtBottom);
			this.pPrawo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pPrawo.Location = new System.Drawing.Point(203, 0);
			this.pPrawo.Name = "pPrawo";
			this.pPrawo.Size = new System.Drawing.Size(589, 566);
			this.pPrawo.TabIndex = 0;
			// 
			// txtBody
			// 
			this.txtBody.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtBody.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.txtBody.Location = new System.Drawing.Point(0, 0);
			this.txtBody.Name = "txtBody";
			this.txtBody.ReadOnly = true;
			this.txtBody.Size = new System.Drawing.Size(589, 423);
			this.txtBody.TabIndex = 0;
			this.txtBody.Text = "";
			// 
			// sTexts
			// 
			this.sTexts.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.sTexts.Location = new System.Drawing.Point(0, 423);
			this.sTexts.Name = "sTexts";
			this.sTexts.Size = new System.Drawing.Size(589, 3);
			this.sTexts.TabIndex = 1;
			this.sTexts.TabStop = false;
			// 
			// txtBottom
			// 
			this.txtBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.txtBottom.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.txtBottom.Location = new System.Drawing.Point(0, 426);
			this.txtBottom.Name = "txtBottom";
			this.txtBottom.ReadOnly = true;
			this.txtBottom.Size = new System.Drawing.Size(589, 140);
			this.txtBottom.TabIndex = 2;
			this.txtBottom.Text = "";
			// 
			// sBelka
			// 
			this.sBelka.Location = new System.Drawing.Point(200, 0);
			this.sBelka.Name = "sBelka";
			this.sBelka.Size = new System.Drawing.Size(3, 566);
			this.sBelka.TabIndex = 1;
			this.sBelka.TabStop = false;
			// 
			// tvDrzewo
			// 
			this.tvDrzewo.Dock = System.Windows.Forms.DockStyle.Left;
			this.tvDrzewo.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.tvDrzewo.ImageIndex = -1;
			this.tvDrzewo.Location = new System.Drawing.Point(0, 0);
			this.tvDrzewo.Name = "tvDrzewo";
			this.tvDrzewo.SelectedImageIndex = -1;
			this.tvDrzewo.Size = new System.Drawing.Size(200, 566);
			this.tvDrzewo.TabIndex = 2;
			this.tvDrzewo.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvDrzewo_AfterSelect);
			// 
			// f_VCGenAssembly
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(792, 566);
			this.Controls.Add(this.pPrawo);
			this.Controls.Add(this.sBelka);
			this.Controls.Add(this.tvDrzewo);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "f_VCGenAssembly";
			this.pPrawo.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region InitializeData
		void InitializeData()
		{
			// available vcgens (static or dynamic)
			//vcGens = CL_VCGens.GetAvailableVCGens( Path.GetDirectoryName( Application.ExecutablePath ) );
			vcGens = CL_VCGens.GetAvailableVCGens();

			// tree
			tvDrzewo.Nodes.Clear();
			foreach ( Type type in assembly.GetTypes() )
			{
				//TreeNode tNode  = new TreeNode( type.Name );
				//tNode.Tag       = type;
				//tNode.ForeColor = Color.Blue;
				//tvDrzewo.Nodes.Add( tNode );

				// constructors				
				foreach (ConstructorInfo constInfo in type.GetConstructors( BindingFlags.DeclaredOnly | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance ))
				{
					string namesp = constInfo.DeclaringType.Namespace;
					if ( namesp == null ) namesp = "no namespace";
					string name = string.Format( "{0}\\{1}\\{2} {3}", 
						namesp.Replace( ".", "\\" ), 
						constInfo.DeclaringType.Name, 
						( constInfo.IsStatic ? "static" : "instance" ),
						Signature( constInfo ) );
					if ( name.StartsWith(".") ) name = name.Substring(1);

					TreeNode tSNode = TreeView_AddNode( tvDrzewo, name ); 
					TreeView_ColorNode( tSNode, Color.Blue, Color.Black );

					tSNode.Tag      = constInfo;
				}

				// methods
				foreach (MethodInfo methodBase in type.GetMethods( BindingFlags.DeclaredOnly | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance ))
				{
					string namesp = methodBase.DeclaringType.Namespace;
					if ( namesp == null ) namesp = "no namespace";
					string name = string.Format( "{0}\\{1}\\{2} {3}", 
						namesp.Replace( ".", "\\" ), 
						methodBase.DeclaringType.Name.Replace( ".", "\\" ),
						( methodBase.IsStatic ? "static" : "instance" ),
						Signature( methodBase ) );
					if ( name.StartsWith(".") ) name = name.Substring(1);

					TreeNode tSNode = TreeView_AddNode( tvDrzewo, name );
					TreeView_ColorNode( tSNode, Color.Blue, Color.Black );

					tSNode.Tag      = methodBase;
				}
			}
		}
		#endregion

		#region Logika, helpery
		string Signature( MethodInfo method )
		{
			StringBuilder sign = new StringBuilder();

			sign.AppendFormat( "{0} ", method.ReturnType.Name );
			sign.AppendFormat( "{0} ", method.Name );
			sign.Append( "(" );
			foreach ( ParameterInfo pi in method.GetParameters() )
			{
				sign.AppendFormat( "{0} {1}, ", pi.ParameterType.Name, pi.Name );
			}
			if ( sign[sign.Length-2] == ',' ) sign.Remove( sign.Length-2, 2 );
			sign.Append( ")" );

			return sign.ToString();
		}
		string Signature( ConstructorInfo method )
		{
			StringBuilder sign = new StringBuilder();

			sign.AppendFormat( "{0} ", method.Name );
			sign.Append( "(" );
			foreach ( ParameterInfo pi in method.GetParameters() )
			{
				sign.AppendFormat( "{0} {1}, ", pi.ParameterType.Name, pi.Name );
			}
			if ( sign[sign.Length-2] == ',' ) sign.Remove( sign.Length-2, 2 );
			sign.Append( ")" );

			return sign.ToString();
		}

		public static void TreeView_ColorNode( TreeNode treeNode, Color parentNodesC, Color childNodeC )
		{
			treeNode.ForeColor = childNodeC;

			treeNode = treeNode.Parent;
			while ( treeNode != null )
			{
				treeNode.ForeColor = parentNodesC;
				treeNode = treeNode.Parent;
			}
		}
		public static TreeNode TreeView_AddNode( TreeView treeView, string nodePath )
		{
			string[] nodePathPart = nodePath.Split( new char[] {'\\'} );

			// poziom g��wny
			TreeNode tCurNode = null;
			foreach ( TreeNode tChild in treeView.Nodes )
				if ( tChild.Text == nodePathPart[0] )
					tCurNode = tChild;
			if ( tCurNode == null )
				tCurNode = treeView.Nodes.Add( nodePathPart[0] );

			// kolejne poziomy
			for ( int iLevel=1; iLevel<nodePathPart.Length; iLevel++ )
			{
				TreeNode tCurNodeChild = null;
				foreach ( TreeNode tChild in tCurNode.Nodes )
					if ( tChild.Text == nodePathPart[iLevel] )
						tCurNodeChild = tChild;
				if ( tCurNodeChild == null )
					tCurNodeChild = tCurNode.Nodes.Add( nodePathPart[iLevel] );

				tCurNode = tCurNodeChild;
			}

			return tCurNode;
		}	
		#endregion

		#region Zdarzenia
		void tvDrzewo_AfterSelect( object sender, TreeViewEventArgs e )
		{
			try
			{
				if ( e.Node != null )
				{
					// methods
					if ( e.Node.Tag is MethodBase )
					{
						MethodBase method = (MethodBase)e.Node.Tag;
						
						// specyfikacje
						StringBuilder spec = new StringBuilder();
						foreach ( IVerificationConditionGenerator vc in vcGens )
						{
							XMS_Spec xms_spec = VCGenBase.GetMethodSpecification( method, vc );
							spec.AppendFormat( "{0}\r\n\r\n", xms_spec );
						}						
						// sygnatura
						string sign = string.Empty;
						if ( method is MethodInfo )
							sign = Signature( (MethodInfo)method );
						if ( method is ConstructorInfo )
							sign = Signature( (ConstructorInfo)method );

						// zdeassemblowany kod
						txtBody.Text = string.Format( "{0}{1}\r\n{2}", spec, sign, VCGenBase.VCMethodBase( method ) );
            
						StringBuilder sb = new StringBuilder();
						foreach ( IVerificationConditionGenerator vc in vcGens )
						{
							sb.Append( vc.VCID );
							sb.Append( "\r\n" );
							sb.Append( vc.VCMethod( (MethodBase)e.Node.Tag ) );
							sb.Append( "\r\n" );
							sb.Append( "\r\n" );
						}
						txtBottom.Text = sb.ToString();
					}
				}
			}
			catch ( Exception ex )
			{
				MessageBox.Show( string.Format( "{0}\r\n\r\n{1}", ex.Message, ex.StackTrace ) );
			}
		}
		#endregion
	}
}
