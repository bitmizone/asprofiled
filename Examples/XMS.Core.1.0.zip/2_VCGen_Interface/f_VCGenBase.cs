// project created on 2004-05-12 at 22:03
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

using UWr.XMS.Base;
using UWr.XMS.VCGen;

namespace UWr.XMS.VCGen.Interface 
{
	class f_VCGenBase : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem mnuLoadAssembly;
		private System.Windows.Forms.MenuItem menuItem;
		private System.Windows.Forms.MenuItem mnuExit;
		public f_VCGenBase()
		{
			InitializeComponent();
			InitializeBackground();
		}
	
		#region InitializeComponent
		void InitializeComponent() 
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(f_VCGenBase));
			this.mnuExit = new System.Windows.Forms.MenuItem();
			this.menuItem = new System.Windows.Forms.MenuItem();
			this.mnuLoadAssembly = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.mainMenu = new System.Windows.Forms.MainMenu();
			// 
			// mnuExit
			// 
			this.mnuExit.Index = 2;
			this.mnuExit.Text = "Exit";
			this.mnuExit.Click += new System.EventHandler(this.MnuExitClick);
			// 
			// menuItem
			// 
			this.menuItem.Index = 0;
			this.menuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mnuLoadAssembly,
																					 this.menuItem3,
																					 this.mnuExit});
			this.menuItem.Text = "File";
			// 
			// mnuLoadAssembly
			// 
			this.mnuLoadAssembly.Index = 0;
			this.mnuLoadAssembly.Text = "Load assembly";
			this.mnuLoadAssembly.Click += new System.EventHandler(this.MnuLoadAssemblyClick);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.Text = "-";
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuItem});
			// 
			// f_VCGenBase
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(440, 289);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu;
			this.Name = "f_VCGenBase";
			this.Text = "Verification Condition Generator v.0.0.1";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

		}
		#endregion
			
		private void InitializeBackground()
		{
			foreach (Control c in this.Controls)
			{
				if ( c is MdiClient )
				{
					((MdiClient)c).Paint += new PaintEventHandler(PaintClientBG);
					((MdiClient)c).SizeChanged+=new EventHandler(SizeClientBG);					
				}
			}
		}
		protected void SizeClientBG(object sender,EventArgs e)
		{
			((MdiClient)sender).Invalidate();
		}
		protected void PaintClientBG(object sender, PaintEventArgs e)
		{
			MdiClient mC = (MdiClient)sender;
			e.Graphics.Clip = new Region( e.ClipRectangle );

			using ( LinearGradientBrush lgb = 
						new LinearGradientBrush( mC.ClientRectangle, 
						                         Color.Navy,
						                         Color.Blue, 
						                         -40f, false ) )
				e.Graphics.FillRectangle( lgb, mC.ClientRectangle );
		}
		
		void MnuExitClick(object sender, System.EventArgs e)
		{
			Close();
		}
		
		void MnuLoadAssemblyClick(object sender, System.EventArgs e)
		{
			OpenFileDialog of   = new OpenFileDialog();
			of.Filter           = "Libraries, executables (*.exe, *.dll)|*.exe;*.dll|All files (*.*)|*.*";
			of.InitialDirectory = Application.ExecutablePath;
			
			if ( of.ShowDialog() == DialogResult.OK )
			{
				try
				{
					Assembly assembly = Assembly.LoadFrom( of.FileName );
					
					f_VCGenAssembly f = new f_VCGenAssembly( assembly );
					f.MdiParent       = this;
					f.Show();
				}
				catch( Exception ex )
				{
					MessageBox.Show( ex.Message, "Error!" );
				}
			}
		}
		
		[STAThread]
		public static void Main(string[] args)
		{
			//TextWriterTraceListener trace = new TextWriterTraceListener( new StreamWriter( "log.txt" ) );
			//Trace.Listeners.Add( trace );

			Application.Run(new f_VCGenBase());

			//trace.Close();
		}

	}			
}
