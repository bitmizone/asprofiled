using System;
using System.Reflection;

using UWr.XMS.Base;

namespace UWr.XMS.Util 
{
	public class AttributeReader 
	{
		public static void PrintAttributes( Assembly a )
		{
			foreach ( Type t in a.GetTypes() )
				foreach ( MethodInfo m in t.GetMethods() )
					foreach ( object o in m.GetCustomAttributes(false) )
					{
						Console.WriteLine( "{0}\r\n\t{1}\r\n\t\t{2}", t, m, o );             
					}      
		}
	}

	public class CMain 
	{
		public static void Main( string[] args ) 
		{      
			if ( args.Length != 1 ) 
			{
				Console.WriteLine( "No params supplied.\r\nExiting." );
			}
			else
			{
				try 
				{
					AttributeReader.PrintAttributes( Assembly.LoadFrom( args[0] ) );
				}
				catch ( Exception ex )
				{
					Console.WriteLine( "Exception caught:\r\n{0}\r\nat\r\n{1}", ex.Message, ex.StackTrace );
				}
			}
		}
	}
}