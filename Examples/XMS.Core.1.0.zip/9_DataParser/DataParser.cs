using System;
using System.Collections;
using System.IO;
using System.Xml;
using System.Text;

namespace UWr.XMS.Util 
{

	public class DataParser 
	{

		public class DataHolder 
		{
			ArrayList data = new ArrayList();

			public void Write( bool b ) 
			{
				data.Add( ( b ? (byte)1 : (byte)0 ) );
			}

			public void Write( byte b ) 
			{
				data.Add( b );
			}

			public void Write( byte[] bs ) 
			{
				foreach ( byte b in bs )
					data.Add( b );
			}

			public void Write( int i ) 
			{
				foreach( byte b in BitConverter.GetBytes( i ) )
					data.Add( b );
			}

			public void Write( short i ) 
			{
				foreach( byte b in BitConverter.GetBytes( i ) )
					data.Add( b );
			}

			public void Write( string s ) 
			{
				byte[] bs = Encoding.UTF8.GetBytes( s );
				WritePackedInt( (uint)bs.Length );
				foreach ( byte b in bs )
					data.Add( b );
			}

			public void WritePackedInt( uint i )
			{
				if ( i>=0 && i<=0x7F )
					Write( (byte)i );
				else if ( i>=0x80 && i<0x3FFF )
				{
					Write( (short)(i & 0x8000) );
				}
				else
				{
					Write( (int)(i & 0x80000000) );
				}
			}

			public string ReadString() 
			{
				StringBuilder sb = new StringBuilder();
				int n=0;

				sb.Append( "(" );
				foreach( byte b in data )
				{
					sb.Append( b.ToString( "x2" ).ToUpper() );
					sb.Append( " " );
					if ( n++>20 ) { n=0; sb.Append( "\r\n" ); }
				}
				sb.Append( ")" );

				return sb.ToString();
			}

			public DataHolder() {}
		}

		const short PROLOG   = 0x0001;
		const short NUMNAMED = 0x0000;

		public static string ProcessElems( XmlNode xmlMethod ) 
		{
			DataHolder  dh = new DataHolder();  
			XmlNodeList nl = xmlMethod.SelectNodes( "Elem" );

			// prolog
			dh.Write( PROLOG );
			// data
			foreach( XmlNode n in nl )
			{
				string st = n.Attributes["type"].Value;
				Type    t = Type.GetType( st );

				if ( t == typeof(System.Boolean) )
				{
					bool b = bool.Parse( n.Attributes["value"].Value );
					dh.Write( b );
				}
				if ( t == typeof(System.Int32) )
				{
					int v = int.Parse( n.Attributes["value"].Value );
					dh.Write( v );
				}
				if ( t == typeof(System.String) )
				{
					dh.Write( (string)n.Attributes["value"].Value );
				}
			}
			// numnamed
			dh.Write( NUMNAMED );

			return dh.ReadString();
		}

		public static void ProcessFile( string fName )
		{
			XmlDocument xml = new XmlDocument();
			xml.Load( fName );

			foreach ( XmlNode nMethod in xml.SelectNodes( "//Param/Method" ) )
			{
				Console.WriteLine( nMethod.Attributes["name"].Value );
				Console.WriteLine( ProcessElems( nMethod ) );    		
			}
		}
	}

	public class CMain 
	{
		public static void Main(string[] args) 
		{
			if ( args.Length != 1 ) 
			{
				Console.WriteLine( "No params supplied.\r\nExiting." );
			}
			else
			{
				try 
				{
					DataParser.ProcessFile( args[0] );
				}
				catch ( Exception ex )
				{
					Console.WriteLine( "Exception caught:\r\n{0}\r\nat\r\n{1}", ex.Message, ex.StackTrace );
				}
			}
		}
	}
}