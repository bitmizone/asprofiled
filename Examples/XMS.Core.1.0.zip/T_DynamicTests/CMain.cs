using System;
using System.Collections;
using System.Diagnostics;

namespace UWr.XMS.Tests
{
	public class CMain
	{
		[STAThread]
		static void Main(string[] args)
		{
			Trace.Listeners.Add( new TextWriterTraceListener( Console.Out ) );

			#region TestSuite1			
			
			TestSuite1 ts = new TestSuite1();

            /* this should pass */
			int int1 = ts.TestInt1( 5, 6 );
            /* this should fail ( precondition ) */
            int array = ts.TestInt1( -5, 6 );

            ArrayList arraylist = new ArrayList();
            /* this should pass */
			int count0 = ts.TestArrayListCount( arraylist );
            arraylist.Add( 1 );
            /* this shoudl fail ( postcondition ) */
            int count1 = ts.TestArrayListCount( arraylist );

            /* this should pass */
            ArrayList arrayList = ts.FactoryMethod();

			int[] x = new int[5]; x[0] = 0;
			ts.TestArray_1( x );
            ts.TestArray_2( x );
            ts.TestArray_3( x );
            ts.TestArray_4( x );			
			
			#endregion

			#region TestSuite2
            
			//TestSuite2 ts2 = new TestSuite2();

			int u = 0, v = 1;
			Console.WriteLine( "u:{0} v:{1}", u, v );
			ts.Swap( ref u, ref v );
			Console.WriteLine( "u:{0} v:{1}", u, v );
            
			#endregion

			Console.ReadLine();
		}
	}
}