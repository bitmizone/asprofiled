using System;
using System.Collections;
using System.Runtime.Remoting;

using UWr.XMS.Base;
using UWr.XMS.Dynamic;

namespace UWr.XMS.Tests
{
	[XMSIntercept]
	public class TestSuite1 : ContextBoundObject
	{
        /// <summary>
        /// Sum of provded parameters. 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
		[Process(typeof(XMSProcessor))]
		[XMS_Spec( 
            "x >= 0 && y >= 0", /* precondition */
            "VALUE == x+y",     /* postcondition */
            ""                  /* invariants */
            )]
		public int TestInt1( int x, int y )
		{
			return x+y;
		}
				
        /// <summary>
        /// Postcondition refers to VALUE returned by the method.
        /// </summary>
        /// <param name="a"></param>
        /// <returns></returns>
		[Process(typeof(XMSProcessor))]
		[XMS_Spec( "notnull(a)", "VALUE == 1", "" )]
		public int TestArrayListCount( ArrayList a )
		{
			a.Add(1);
			return a.Count;
		}

        /// <summary>
        /// Example of builtin notnull(*) predicate.
        /// </summary>
        /// <returns></returns>
        [Process( typeof( XMSProcessor ) )]
        [XMS_Spec( "true", "notnull(a)", "" )]
        public ArrayList FactoryMethod()
        {
            ArrayList a = new ArrayList();

            return a;
        }

        /// <summary>
        /// Precondition checks if valid array is provided.
        /// </summary>
        /// <param name="a"></param>
		[Process(typeof(XMSProcessor))]
		[XMS_Spec( "notnull(a)", "true", "" )]
		public void TestArray_1( int[] a )
		{
			return;
		}

        /// <summary>
        /// Precondition checks the contents of an array.
        /// </summary>
        /// <param name="a"></param>
		[XMS_Spec( "a[0] == 0", "true", "" )]
		[Process(typeof(XMSProcessor))]
		public void TestArray_2( int[] a )
		{
			return;
		}

        /// <summary>
        /// Precondition checks the contents of an array.
        /// </summary>
        /// <param name="a"></param>
        [Process( typeof( XMSProcessor ) )]
		[XMS_Spec( "a[0] + a[1] == 0", "true", "" )]
		public void TestArray_3( int[] a )
		{
			return;
		}

        /// <summary>
        /// Precondition checks the contents of an array.
        /// </summary>
        /// <param name="a"></param>
        [Process( typeof( XMSProcessor ) )]
		[XMS_Spec( "a[a[0]] == 0", "true", "" )]
		public void TestArray_4( int[] a )
		{
			return;
		}

        /// <summary>
        /// Postcondition can refer to original values of parameters.
        /// </summary>
        /// <param name="a"></param>
        [Process( typeof( XMSProcessor ) )]
        [XMS_Spec( "true", "x == y_ORIGINAL && y == x_ORIGINAL", "" )]
        public void Swap( ref int x, ref int y )
        {
            int z = x;
            x = y;
            y = z;
        }		
	}
}
