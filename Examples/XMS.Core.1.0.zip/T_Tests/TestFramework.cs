using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

using UWr.XMS.Base;
using UWr.XMS.VCGen;
using UWr.XMS.VCGen.Lexing;
using UWr.XMS.VCGen.Parsing;

namespace Uwr.XMS.Tests
{
  #region Test method
  public class TestedMethod
  {
    [XmlAttribute("name")]
    public string name;

    [XmlAttribute("type")]
    public string type;
    
    [XmlIgnore()]
    public XMS_Spec spec;      
    [XmlAttribute("spec")]
    public string specstring
    {
      get
      {
        return spec.ToString();
      }
      set {}
    }
    
    [XmlAttribute("evc")]
    public string evc;    
    [XmlAttribute("vc")]
    public string vc;

    [XmlAttribute("status")]
    public string status
    {
      get
      {
        return evc==vc ? "Pass" : "Fail";
      }
      set{}
    }
    [XmlAttribute("color")]
    public string color
    {
      get
      {
        return evc==vc ? "#00ff00" : "#ff0000";
      }
      set{}
    }
    
    public TestedMethod() {}

    public TestedMethod( string name, string type, XMS_Spec spec, string evc, string vc )
    {
      this.name = name;
      this.type = type;
      this.spec = spec;
      this.evc  = evc;
      this.vc   = vc;
    }
  }      
  
  public class TestedType
  {
    [XmlAttribute("name")]
    public string name;
    [XmlAttribute("methodCount")]
    public int methodCount;
    [XmlAttribute("methodPassed")]
    public int methodPass;    
    
    public TestedType() {}

    public TestedType( string name )
    {
      this.name = name;
    }
      
    [XmlElement("Method", typeof(TestedMethod) )]
    public ArrayList Methods = new ArrayList();
  }
  
  [XmlRoot("TestSuite", Namespace="")]
  public class TestInstance
  {    
    [XmlAttribute("date")]
    public string date
    {
      get
      {
        return DateTime.Now.ToString("g");
      }
      set {}
    }      
      
    [XmlElement( "Type", typeof(TestedType) )]
    public ArrayList TestedTypes = new ArrayList();      
      
    public TestInstance() {}
  }
  
  public class TestSuite : Attribute 
  {
	  private string[] m_methodName;
	  public string[] MethodNames
	  {
		  get
		  {
			  return m_methodName;
		  }
	  }

	  public TestSuite() {}
	  public TestSuite( string[] MethodNames )
	  {
		  this.m_methodName = MethodNames;
	  }
  }

  public class Test : Attribute {}
    
  public class ExpectedVC : Attribute
  {
    public string Predicate;
	  
    public ExpectedVC( string predicate )
    {
      this.Predicate = predicate;
    }
  }
  #endregion
  
  #region Test Framework
  public class TestFramework
  {
    public static void PerformTests()
    {
      XmlTextWriter testRes = new XmlTextWriter( "testresults.xml", Encoding.GetEncoding(1250) );
      testRes.Formatting = Formatting.Indented;
      testRes.Indentation = 2;

      testRes.WriteProcessingInstruction( "xml-stylesheet", "href=\"xmstestsuite.xsl\" type=\"text/xsl\"" );
      testRes.WriteProcessingInstruction( "xml", "version=\"1.0\" encoding=\"windows-1250\"" );
      
      PerformTests( testRes );
      
      testRes.Close();
    }

    public static void PerformTests( XmlTextWriter outputStream )
    {
      TestInstance testDesc = new TestInstance();
      
      foreach ( Type type in Assembly.GetExecutingAssembly().GetTypes() )
        foreach ( object attrib in type.GetCustomAttributes(true) )
          if ( attrib is TestSuite )
          {
            Console.WriteLine( "Testing type {0}:\r\n", type.FullName );

            string[] methodNames = ((TestSuite)attrib).MethodNames;

            // perform tests for this type
            TestedType testedType = new TestedType( type.FullName );
            testDesc.TestedTypes.Add( testedType );

  		    // constructors
			foreach ( MethodBase mb in type.GetConstructors( BindingFlags.DeclaredOnly | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance ) )
			{
			  Console.WriteLine( Signature( mb ) );
			  PerformTestForMethod( mb, testedType, methodNames );                                                  
			}
            
            // methods
			foreach ( MethodBase mb in type.GetMethods( BindingFlags.DeclaredOnly | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance ) )
			{
			  Console.WriteLine( Signature( mb ) );
			  PerformTestForMethod( mb, testedType, methodNames );                                                  
			}

            // count them
            int c=0, p=0;
			foreach ( TestedMethod m in testedType.Methods )
			{
				c++;
				if ( m.status == "Pass" ) p++;
			}
            testedType.methodCount = c;
            testedType.methodPass  = p;
          }
                    
      // save result
      XmlSerializer xs = new XmlSerializer( typeof( TestInstance ) );
      xs.Serialize( outputStream, testDesc );      
    }
    
	  private static string Signature( MethodBase methodBase )
	  {
		  if ( methodBase is MethodInfo )
		  {
			  MethodInfo method = methodBase as MethodInfo;

			  StringBuilder sign = new StringBuilder();

			  sign.AppendFormat( "{0} ", method.ReturnType.Name );
			  sign.AppendFormat( "{0} ", method.Name );
			  sign.Append( "(" );
			  foreach ( ParameterInfo pi in method.GetParameters() )
			  {
				  sign.AppendFormat( "{0} {1}, ", pi.ParameterType.Name, pi.Name );
			  }
			  if ( sign[sign.Length-2] == ',' ) sign.Remove( sign.Length-2, 2 );
			  sign.Append( ")" );

			  return sign.ToString();
		  }
		  else if ( methodBase is ConstructorInfo )
		  {
			  ConstructorInfo method = methodBase as ConstructorInfo;

			  StringBuilder sign = new StringBuilder();

			  sign.AppendFormat( "{0} ", method.Name );
			  sign.Append( "(" );
			  foreach ( ParameterInfo pi in method.GetParameters() )
			  {
				  sign.AppendFormat( "{0} {1}, ", pi.ParameterType.Name, pi.Name );
			  }
			  if ( sign[sign.Length-2] == ',' ) sign.Remove( sign.Length-2, 2 );
			  sign.Append( ")" );

			  return sign.ToString();
		  }
		  else
			  throw new Exception( "No method or constructor passed to Signature!" );
	  }

		public static void PerformTestForMethod( MethodBase mb, TestedType testedType, string[] methodNames )
		{
			if ( methodNames == null || Array.IndexOf( methodNames, mb.Name ) >= 0 )
			{
				XMS_Spec   spec = null;
				ExpectedVC evc  = null;

				try
				{
					IVerificationConditionGenerator vcgen = new VCGen_Prop();
	      
					foreach ( object mba in mb.GetCustomAttributes(true) )
					{
						if ( mba is XMS_Spec ) spec = (XMS_Spec)mba;
						if ( mba is ExpectedVC ) evc = (ExpectedVC)mba;
					}
	                
					if ( spec != null && evc != null )
					{
						string vc = vcgen.VCMethod( mb ).Formula;
	                
						TestedMethod testedMethod = 
							new TestedMethod( Signature( mb ), 
							(mb.IsStatic ? "static" : "instance"), 
							spec, 
							SymbExpr.Parse( evc.Predicate ).Closure.ToString(),
							vc );
						testedType.Methods.Add( testedMethod );
					}
				}
				catch( Exception ex )
				{
					TestedMethod testedMethod = 
						new TestedMethod( Signature( mb ), 
						(mb.IsStatic ? "static" : "instance"), 
						spec,
						SymbExpr.Parse( evc.Predicate ).Closure.ToString(), 
						string.Format( "Failed with: {0} at {1}", ex.Message, ex.StackTrace ) );
					testedType.Methods.Add( testedMethod );
				}
			}
		}      
  }

    public class MainClass
    {
        public static void Main( string[] args )
        {
            try
            {
                AnalyzeRuntimeParameters( args );

                TestFramework.PerformTests();

                //Console.ReadLine();
            }
            catch ( Exception ex )
            {
                Console.WriteLine( "Exception caught: {0}\r\n\r\n{1}", ex.Message, ex.StackTrace );
            }
        }

        static void AnalyzeRuntimeParameters( string[] args )
        {
            if ( Array.IndexOf( args, "/trace" ) >= 0 )
            {
                Trace.Listeners.Add( new TextWriterTraceListener( new System.IO.StreamWriter( "xms.trace", false, Encoding.UTF8 ) ) );
                Trace.AutoFlush = true;

                Trace.WriteLine( "----------------------------------------------------" );
                Trace.WriteLine( string.Format( "�ledzenie wykonania: {0}", DateTime.Now ) );
                Trace.WriteLine( "----------------------------------------------------" );
            }
        }
    }
  #endregion
}