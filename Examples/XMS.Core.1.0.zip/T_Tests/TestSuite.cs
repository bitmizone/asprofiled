using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

using UWr.XMS.Base;
using UWr.XMS.VCGen;

namespace Uwr.XMS.Tests
{
    #region Phd thesis tests
    //[TestSuite()]
    public class StaticTestsSuite
    {
        public int a, b, c;

        [XMS_Spec( "true", "this.a = av && this.b = bv && this.c = cv", "" )]
        [ExpectedVC( "true => true" )]
        public StaticTestsSuite( int av, int bv, int cv )
        {
            this.a = av;
            this.b = bv;
            this.c = cv;
        }

        [XMS_Spec( "true", "VALUE = x + x + x", "" )]
        [ExpectedVC( "true => true" )]
        public int TestConstructor( int x )
        {
            StaticTestsSuite ts = new StaticTestsSuite( x, x, x );
            return ts.a + ts.b + ts.c;
        }

        [XMS_Spec( "true", "VALUE = 6", "" )]
        [ExpectedVC( "true => true" )]
        public int MethodCalling()
        {
            int val = 1;

            return 2*TestConstructor( val );
        }

        [XMS_Spec( "x > 0 && y > 0",
             "VALUE = GCD(x,y)",
             "GCD(x,y)=GCD(V_0,V_1):0:V_0,V_1" )]
        [ExpectedVC( "true => true" )]
        public int GCD( int x, int y )
        {
            int k = x;
            int l = y;

            while ( k - l != 0 )
            {
                if ( k > l )
                    k -= l;
                else
                    l -= k;
            }

            return k;
        }

        [XMS_Spec( "true", "VALUE = 3", "" ),
         ExpectedVC( "true => true" )]
        int Arr_SymbolicIndexes( int[] array, int i, int j, int k )
        {
            array[i] = 0;
            array[j] = 1;
            array[k] = 2;

            return array[i] + array[j] + array[k];
        }
    }
    #endregion

    #region Tests 1
    //[TestSuite()]
    //[TestSuite( new string[] { "Sum_I" } )]
    public class Tests_1
    {
        #region Type definition - locals etc.
        public int a, b, c;
        #endregion

        #region Constructors
        [XMS_Spec( 1, "true", "this.a = 0 && this.b = 0 && this.c = 0", "", "", "" )]
        [ExpectedVC( "true => 0 = 0 && 0 = 0 && 0 = 0" )]
        public Tests_1() { }

        [XMS_Spec( 1, "true", "this.a = av && this.b = bv && this.c = cv", "", "", "" )]
        [ExpectedVC( "forall av. forall bv. forall cv. true => av = av && bv = bv && cv = cv" )]
        public Tests_1( int av, int bv, int cv )
        {
            this.a = av;
            this.b = bv;
            this.c = cv;
        }
        #endregion

        #region Return values

        #region null
        [XMS_Spec( 1, "true", "VALUE=null", "", "", "" )]
        [ExpectedVC( "true => null=null" )]
        public static object Const_NULL_S()
        {
            return null;
        }
        #endregion

        #region bool
        [XMS_Spec( 1, "true", "VALUE=true", "", "", "" )]
        [ExpectedVC( "true => true = true" )]
        public static bool Const_Bool_S()
        {
            return true;
        }
        [XMS_Spec( 1, "true", "VALUE=true", "", "", "" )]
        [ExpectedVC( "true => true = true" )]
        public bool Const_Bool_I()
        {
            return true;
        }
        #endregion

        #region int
        [XMS_Spec( 1, "true", "VALUE=1", "", "", "" )]
        [ExpectedVC( "true => 1=1" )]
        public static int Const_Int_S()
        {
            return 1;
        }
        [XMS_Spec( 1, "true", "VALUE=1", "", "", "" )]
        [ExpectedVC( "true => 1=1" )]
        public int Const_Int_I()
        {
            return 1;
        }
        #endregion

        #region double
        [XMS_Spec( 1, "true", "VALUE=1", "", "", "" )]
        [ExpectedVC( "true => 1=1" )]
        public static double Const_Double_S()
        {
            return 1;
        }
        [XMS_Spec( 1, "true", "VALUE=1", "", "", "" )]
        [ExpectedVC( "true => 1=1" )]
        public double Const_Double_I()
        {
            return 1;
        }
        #endregion

        #region string
        [XMS_Spec( 1, "true", "VALUE=\"example\"", "", "", "" )]
        [ExpectedVC( "true => \"example\"=\"example\"" )]
        public static string Const_String_S()
        {
            return "example";
        }
        [XMS_Spec( 1, "true", "VALUE=\"example\"", "", "", "" )]
        [ExpectedVC( "true => \"example\"=\"example\"" )]
        public string Const_String_I()
        {
            return "example";
        }
        #endregion

        #region Value types as parameters and values
        [XMS_Spec( 1, "true", "VALUE = b * b - 4 * a * c", "", "", "" )]
        [ExpectedVC( "forall a. forall b. forall c. true => b * b - 4 * a * c = b * b - 4 * a * c" )]
        public static int Delta_S( int a, int b, int c )
        {
            return b * b - 4 * a * c;
        }
        [XMS_Spec( 1, "true", "VALUE = b * b - 4 * a * c", "", "", "" )]
        [ExpectedVC( "forall a. forall b. forall c. true => b * b - 4 * a * c = b * b - 4 * a * c" )]
        public int Delta_I( int a, int b, int c )
        {
            return b * b - 4 * a * c;
        }

        [XMS_Spec( 1, "true", "VALUE = this.b * this.b - 4 * this.a * this.c", "", "", "" )]
        [ExpectedVC( "forall this.a. forall this.b. forall this.c. true => this.b * this.b - 4 * this.a * this.c = this.b * this.b - 4 * this.a * this.c" )]
        public int Delta_I_L()
        {
            return b * b - 4 * a * c;
        }
        #endregion

        #region Ifs
        [XMS_Spec( 1, "true", "VALUE >= 0", "", "", "" )]
        [ExpectedVC( "forall x. true => (x >= 0 => x >=0) && (x < 0 => -x >= 0)" )]
        public int Abs( int x )
        {
            if ( x >= 0 )
                return x;
            else
                return -x;
        }

        [XMS_Spec( 1, 
            "true", 
            "VALUE = m * n", 
            "V_0 = i*n && i < m:0:V_0,V_1,V_2;V_0 = i*n+j && j < n:0:V_0,V_2", "", "" )]
        [ExpectedVC( "true => true" )]
        public int MTimesN( int m, int n )
        {
            int ret = 0;

            for ( int i = 0; i < m; i++ )
                for ( int j = 0; j < n; j++ )
                    ret++;

            return ret;
        }
        #endregion

        #endregion

        #region Invariants

        #region Value types and invariants

        [XMS_Spec( 1, "x > 0 && y > 0",
             "VALUE = GCD(x,y)",
             "GCD(x,y)=GCD(V_0,V_1):0:V_0,V_1", "", "" )]
        [ExpectedVC( "true => true" )]
        public int GCD( int x, int y )
        {
            int k = x;
            int l = y;

            while ( k - l != 0 )
            {
                if ( k > l )
                    k -= l;
                else
                    l -= k;
            }

            return k;
        }

        [XMS_Spec( 1, "n >= 0", "VALUE=sum(0, n)", "V_0=sum(0, V_1) && n >= V_1:0:V_0,V_1", "", "" )]
        [ExpectedVC( "true => true" )]
        public int Sum_I( int n )
        {
            int sum = 0;
            for ( int k = 0; k <= n; k++ )
            {
                sum += k;
            }

            return sum;
        }
        #endregion

        #endregion

        #region Methods

        [XMS_Spec( 1, "true", "VALUE = y * y - 4 * x * z", "", "", "" )]
        [ExpectedVC( "forall x. forall y. forall z. True => True & (forall Delta_I_. Delta_I_ = y * y - 4 * z * x => Delta_I_ = y * y - 4 * x * z)" )]
        public int Delta_Client_GlobalParams_I( int x, int y, int z )
        {
            return Delta_I( x, y, z );
        }

        [XMS_Spec( 1, "true", "VALUE = 2 * 2 - 4 * 3 * 1", "", "", "" )]
        [ExpectedVC( "True => True && (forall Delta_I_. Delta_I_ = 2 * 2 - 4 * 3 * 1 => Delta_I_ = 2 * 2 - 4 * 3 * 1)" )]
        public int Delta_Client_LocalParams_I()
        {
            return Delta_I( 1, 2, 3 );
        }

        [XMS_Spec( 1, "true", "VALUE = y * y - 4 * x * z", "", "", "" )]
        [ExpectedVC( "forall Tests_1_.a. forall Tests_1_.b. forall Tests_1_.c. forall x. forall y. forall z. True => (Tests_1_.a = z & Tests_1_.b = y & Tests_1_.c = x => True & (forall Delta_I_L_. Delta_I_L_ = Tests_1_.b * Tests_1_.b - 4 * Tests_1_.a * Tests_1_.c => Delta_I_L_ = y * y - 4 * x * z))" )]
        public int Delta_Client_InstanceGlobalParams_I( int x, int y, int z )
        {
            Tests_1 t = new Tests_1( x, y, z );
            return t.Delta_I_L();
        }

        [XMS_Spec( 1, "true", "VALUE = 2 * 2 - 4 * 3 * 1", "", "", "" )]
        [ExpectedVC( "forall Tests_1_.a. forall Tests_1_.b. forall Tests_1_.c. True => (Tests_1_.a = 3 & Tests_1_.b = 2 & Tests_1_.c = 1 => True & (forall Delta_I_L_. Delta_I_L_ = Tests_1_.b * Tests_1_.b - 4 * Tests_1_.a * Tests_1_.c => Delta_I_L_ = 2 * 2 - 4 * 3 * 1))" )]
        public int Delta_Client_InstanceLocalParams_I()
        {
            Tests_1 t = new Tests_1( 1, 2, 3 );
            return t.Delta_I_L();
        }

        #endregion

        #region Objects

        #region Object as parameter
        [XMS_Spec( 1, "true", "h.n = 1", "", "", "" )]
        [ExpectedVC( "true => 1 = 1" )]
        public static void CreateObject_P( HelperClass1 h )
        {
            h.n = 1;
        }
        #endregion

        #region Object as return value
        [XMS_Spec( 1, "true", "VALUE.n = 1", "", "", "" )]
        [ExpectedVC( "forall HelperClass1_.n. True => (HelperClass1_.n = 0 => 1 = 1)" )]
        public static HelperClass1 CreateObject_RV()
        {
            HelperClass1 h = new HelperClass1();
            h.n = 1;

            return h;
        }

        [XMS_Spec( 1, "true", "VALUE.n = v", "", "", "" )]
        [ExpectedVC( "forall HelperClass1_.n. forall v. True => (HelperClass1_.n = 0 => v = v)" )]
        public static HelperClass1 CreateObject_RV( int v )
        {
            HelperClass1 h = new HelperClass1();
            h.n = v;

            return h;
        }
        #endregion

        #region Object as parameter & return value
        [XMS_Spec( 1, "true", "h.n = 1 && VALUE = h", "", "", "" )]
        [ExpectedVC( "forall h. true => 1 = 1 && h = h" )]
        public static HelperClass1 CreateObject_PRV( HelperClass1 h )
        {
            h.n = 1;

            return h;
        }

        [XMS_Spec( 1, "true", "h.n = v && VALUE = h", "", "", "" )]
        [ExpectedVC( "true => v = v && h = h" )]
        public static HelperClass1 CreateObject_PRVV( HelperClass1 h, int v )
        {
            h.n = v;

            return h;
        }
        #endregion

        #region Recursive objects

        [XMS_Spec( 1, "true", "VALUE.child.n = 1", "", "", "" )]
        [ExpectedVC( "true => true" )]
        public static HelperClass1 RecObj_1()
        {
            HelperClass1 h = new HelperClass1();
            h.child = new HelperClass1();
            h.child.child = new HelperClass1();

            h.child.child.n = 1;

            return h.child;
        }

        [XMS_Spec( 1, "true", "VALUE.n = 1", "", "", "" )]
        [ExpectedVC( "forall HelperClass1_.n. forall HelperClass1__.n. forall HelperClass1___.n. True => (HelperClass1_.n = 0 => (HelperClass1__.n = 0 => (HelperClass1___.n = 0 => 1 = 1)))" )]
        public static HelperClass1 RecObj_2()
        {
            HelperClass1 h = new HelperClass1();
            h.child = new HelperClass1();
            h.child.child = new HelperClass1();

            h.child.child.n = 1;

            return h.child.child;
        }

        #endregion

        #region Anonymous objects
        [XMS_Spec( 1, "true", "VALUE.n = 1", "", "", "" )]
        [ExpectedVC( "forall HelperClass1_.n. True => (HelperClass1_.n = 1 => HelperClass1_.n = 1)" )]
        public static HelperClass1 CreateObject_ARV()
        {
            return new HelperClass1( 1 );
        }

        [XMS_Spec( 1, "true", "VALUE.n = v", "", "", "" )]
        [ExpectedVC( "forall HelperClass1_.n. forall v. True => (HelperClass1_.n = v => HelperClass1_.n = v)" )]
        public static HelperClass1 CreateObject_ARV( int v )
        {
            return new HelperClass1( v );
        }
        #endregion

        #endregion

        #region Unsafe
        [XMS_Spec( 1, "true", "true", "", "", "" )]
        [ExpectedVC( "true => true" )]
        unsafe void Unsafe_1( int x, ref Test t, out int y )
        {
            int* z = &x;

            y = *z;
        }
        #endregion

        #region Other
        [XMS_Spec( 1, "true", "VALUE.n = 0", "", "", "" )]
        [ExpectedVC( "true => 1 = 1" )]
        public static HelperClass1 IF_2()
        {
            HelperClass1 h = new HelperClass1();

            RET_0( h );
            RET_1( h );

            return h;
        }

        [XMS_Spec( 1, "true", "VALUE.n = 0", "", "h.n", "" )]
        [ExpectedVC( "true => 0 = 0" )]
        static HelperClass1 RET_0( HelperClass1 h )
        {
            h.n = 0;
            return h;
        }
        [XMS_Spec( 1, "true", "VALUE.n = 1", "", "h.n", "" )]
        [ExpectedVC( "true => 1 = 1" )]
        static HelperClass1 RET_1( HelperClass1 h )
        {
            h.n = 1;
            return h;
        }

        [XMS_Spec( 1, "true", "true", "", "", "" ),
         ExpectedVC( "true => true" )]
        static void ModifVars_1( HelperClass1 h, ref int x )
        {
            int y;
            h.n = 5;
            y = x;
            x = 7;
        }
        #endregion
    }  
	#endregion  

    #region Tests 2
    //[TestSuite()]
    //[TestSuite( new string[] { "set_Property1" } )]
    public class Tests_2
    {
        [XMS_Spec( 1, "true", "VALUE = y", "", "", "" ),
         ExpectedVC( "true => true" )]
        static int Return( int y )
        {
            int x;

            x = 0;
            x = 1;

            x = y;

            return x;
        }

        [XMS_Spec( 1, "true", "VALUE = (7 * a) / (14 + b)", "", "", "" ),
         ExpectedVC( "true => true" )]
        static int Expression( int a, int b )
        {
            return ( 7 * a ) / ( 14 + b );
        }

        [XMS_Spec( 1, "true", "(VALUE % 2 == 0)", "", "", "" ),
         ExpectedVC( "true => true" )]
        static int If( int a )
        {
            if ( ( a % 2 ) == 0 )
                return a;
            else
                return a + 1;
        }

        [XMS_Spec( 1, "true", "(VALUE % 2) == 0", "", "", "" ),
         ExpectedVC( "true => true" )]
        static int IfCaller( int x )
        {
            int y = If( x );

            return y * 2;
        }

        [XMS_Spec( 1, "true", "true", "", "", "" ),
         ExpectedVC( "true => true" )]
        static int LongMethod( int x, Predicate<int> f )
        {
            if ( f( x ) )
                return x;

            return 0;
        }

        private static int property1;
        static int Property1
        {
            [XMS_Spec( 1, "true", "VALUE = Uwr.XMS.Tests.Tests_2.property1", "", "", "" ),
             ExpectedVC( "true => true" )]
            get
            {
                return property1;
            }
            [XMS_Spec( 1, "true", "Uwr.XMS.Tests.Tests_2.property1 = value", "", "", "" ),
             ExpectedVC( "true => true" )]
            set
            {
                property1 = value;
            }
        }

        int this[int n]
        {
            [XMS_Spec( 1, "true", "VALUE = 0", "", "", "" ),
            ExpectedVC( "true => 0 = 0" )]
            get
            {
                return 0;
            }
        }

        [XMS_Spec( 1, "true", "true", "", "", "" ),
         ExpectedVC( "true => this.Property1 = 1" )]
        static void Property1_Client()
        {
            Property1 = 1;
        }
    }
    #endregion

    #region Arrays
    //[TestSuite()]
    //[TestSuite( new string[] { "Arr_Swap" } )]
    //[TestSuite( new string[] { "Arr_K0" } )]    
    public class Test_Arrays
    {
        [XMS_Spec( 1, "true", "VALUE = array.Length", "", "", "" ),
         ExpectedVC( "true => true" )]
        int Arr_Length( int[] array )
        {
            return array.Length;
        }

        [XMS_Spec( 1, "true", "VALUE = array[0]", "", "", "" ),
         ExpectedVC( "true => true" )]
        int Arr_Zero( int[] array )
        {
            return array[0];
        }

        [XMS_Spec( 1, "true", "VALUE = array[k]", "", "", "" ),
         ExpectedVC( "true => true" )]
        int Arr_K( int[] array, int k )
        {
            return array[k];
        }

        [XMS_Spec( 1, "true", "array[k] = 0", "", "", "" ),
         ExpectedVC( "true => true" )]
        void Arr_K0( int[] array, int k )
        {
            array[k] = 0;
        }

        [XMS_Spec( 1, "true", "VALUE = 3", "", "", "" ),
         ExpectedVC( "true => true" )]
        int Arr_SymbolicIndexes( int[] array, int i, int j, int k )
        {
            array[i] = 0;
            array[j] = 1;
            array[k] = 2;

            return array[i] + array[j] + array[k];
        }

        [XMS_Spec( 1, "true", "VALUE = 1", "", "", "" ),
         ExpectedVC( "true => true" )]
        int Arr_FixedValue()
        {
            int[] n = new int[10];

            n[0] = 1;

            return n[0];
        }

        [XMS_Spec( 1, "true", "array.Length > 2 => VALUE = true && array.Length <= 2 => VALUE = false", "", "", "" ),
         ExpectedVC( "true => true" )]
        bool Arr_2( int[] array )
        {
            return array.Length > 2;
        }

        [XMS_Spec( 1, "array.Length > 0", "true", "forall k. k < i => v <= array[k]:0:V_0,V_1", "", "" ),
         ExpectedVC( "true => true" )]
        public int FindMin( int[] array )
        {
            int v = array[0];
            for ( int i = 0; i < array.Length; i++ )
                if ( array[i] < v )
                    v = array[i];

            return v;
        }

        [XMS_Spec( 1, "precondition", "postcondition", "invariant:0:V_0,V_1,V_3", "", "" ),
         ExpectedVC( "true => true" )]
        public int FindMin_Foreach( int[] array )
        {
            int v = array[0];
            foreach ( int a in array )
                if ( a < v )
                    v = a;

            return v;
        }
    }
    #endregion

    #region Real-life example
    //   [TestSuite()]
    public class Person
    {
        [XMS_Spec( 1, "true", "true", "", "", "" ),
         ExpectedVC( "true => this.Age = 0" )]
        public Person() { }

        [XMS_Spec( 1, "true", "true", "", "", "" ),
         ExpectedVC( "true => this.age = iAge" )]
        public Person( int iAge ) 
        {
            this.age = iAge;
        }

        private int age;
        public int Age
        {
            [XMS_Spec( 1, "true", "VALUE = this.age", "", "", "" ),
             ExpectedVC( "true => true" )]
            get
            {
                return age;
            }
            [XMS_Spec( 1, "true", "this.age = value", "", "", "" ),
             ExpectedVC( "true => true" )]
            set
            {
                age = value;
            }
        }

    }
    #endregion

    #region 0-values
    //[TestSuite()]
    class Test0Values
    {
        [XMS_Spec( 1, "true", "array[k] = array_ORIGINAL[l]", "", "", "" ),
         ExpectedVC( "true => true" )]
        void Arr_Swap( int[] array, int k, int l )
        {
            #warning This will not work until 0-values are allowed in postconditions
            int temp;
            temp = array[k];
            array[k] = array[l];
            array[l] = temp;
        }
    }

    //[TestSuite()]
    //[TestSuite( new string[] { "TableOfObjects_1" } )]
    //[TestSuite( new string[] { "CloneObjects" } )]
    class TestVaria
    {
        public int k;
        public int l;

        [XMS_Spec( 1, "true", "VALUE.k == 2 && ( VALUE.l == 4 || VALUE.l == 0 )", "", "", "" ),
         ExpectedVC( "true => true" )]
        TestVaria CloneObjects( int param )
        {
            TestVaria t = new TestVaria();
            TestVaria u = new TestVaria();

            t.k = 2;
            t.l = 2;
            u.k = 2;

            if ( param > 0 )
                t.l += 2;
            else
                t.l -= 2;

            return t;
        }

        [XMS_Spec( 1, "true", "VALUE[0].k == 2", "", "", "" ),
         ExpectedVC( "true => true" )]
        TestVaria[] TableOfObjects_1( TestVaria[] array )
        {
            array[0] = new TestVaria();
            array[0].k = 2;

            return array;
        }

        [XMS_Spec( 1, "true", "VALUE[0].k == 2", "", "", "" ),
         ExpectedVC( "true => true" )]
        TestVaria[] TableOfObjects_12( TestVaria[] array )
        {
            array[0] = new TestVaria();
            array[0].k = 2;

            return array;
        }

        [XMS_Spec( 1, "true", "VALUE.k == 2", "", "", "" ),
         ExpectedVC( "true => true" )]
        TestVaria TableOfObjects_Q( TestVaria inst )
        {
            inst.k = 2;

            return inst;
        }

        [XMS_Spec( 1, "true", "VALUE[0].k == 2", "", "", "" ),
         ExpectedVC( "true => true" )]
        TestVaria[] TableOfObjects_2()
        {
            TestVaria[] array = new TestVaria[1];
            array[0] = new TestVaria();
            array[0].k = 2;

            return array;
        }

        [XMS_Spec( 1, "true", "VALUE[VALUE[0]] == 0", "", "", "" ),
         ExpectedVC( "true => true" )]
        int[] TableOfTables( int[] tab )
        {
            tab[0] = 1;
            tab[1] = 0;

            return tab;
        }
    }
    #endregion

    #region Yet another bunch of tests
    [TestSuite]
    class YetAnotherBunchOfTests
    {
        [XMS_Spec( "true", "VALUE = 1", "(x >= 0):0:V_0,V_1" )]
        //[ExpectedVC( "true => true" )]
        int OneLoop()
        {
            int x = 0;

            for ( int i = 0; i < 10; i++ )
            {
                x += i;

                x = 1;
            }

            return x;
        }

        [XMS_Spec( "true", "VALUE = 1", "(V_0 >= 0):0:V_0,V_1,V_2;(V_0 >= 0):0:V_0,V_2" )]
        //[ExpectedVC( "true => true" )]
        int TwoLoops()
        {
            int x = 0;

            for ( int i = 0; i < 10; i++ )
            {
                x += i;

                for ( int j = 0; j < 10; j++ )
                {
                    x += j;
                }

                x = 1;
            }

            return x;
        }

        [XMS_Spec( "true", "VALUE = 1", "(V_0 >= 0):0:V_0;(V_0 >= 0):0:V_0" )]
        //[ExpectedVC( "true => true" )]
        int TwoSimpleLoops()
        {
            int x = 0;

            for ( ; x < 9999 ; )
            {
                x += 1;

                for ( ; x < 9999 ; )
                {
                    x += 2;
                }

                x = 1;
            }

            return x;
        }

        [XMS_Spec( "true", "VALUE = 1", "" )]
        //[ExpectedVC( "true => true" )]
        int Ret1( int y, int z )
        {
            int x;

            y = 1;
            z = 2;

            x = y + z;

            return x;
        }

        [XMS_Spec( "true", "VALUE = y_ORIGINAL", "" )]
        //[ExpectedVC( "true => true" )]
        int ZeroVal( int y )
        {
            int x = y;
            y = 1;

            return x;
        }

        [XMS_Spec( 1, "true", "VALUE = 3", "", "", "" )]
        //[ExpectedVC( "true => true" )]
        int ArrOv( int[] array, int i, int j )
        {
            array[i] = 1;
            array[j] = 2;

            return array[i] + array[j];
        }

        [XMS_Spec( 1, "true", "VALUE = 3", "", "", "" )]
        //[ExpectedVC( "true => true" )]
        int Arr2Loc( int i, int j )
        {
            int[] array = new int[2];

            array[i] = 1;
            array[j] = 2;

            return array[i] + array[j];
        }

        [XMS_Spec( 1, "i != j", "VALUE = 3", "", "", "" )]
        [ExpectedVC( "true => true" )]
        int Arr2( int[] array, int i, int j )
        {
            array[i] = 1;
            array[j] = 2;

            return array[i] + array[j];
        }

        [XMS_Spec( 1, "true", "VALUE = 3", "", "", "" )]
        [ExpectedVC( "true => true" )]
        int Arr2Ov( int[] array, int i, int j )
        {
            array[i] = 1;
            array[i] = 1;
            array[j] = 2;

            return array[i] + array[j];
        }

        [XMS_Spec( 1, "true", "VALUE = 3", "", "", "" )]
        [ExpectedVC( "true => true" )]
        int Arr2Ov2( int[] array, int i, int j )
        {
            array[i] = 1;
            array[j] = 1;
            array[i] = 2;

            return array[i] + array[j];
        }

        [XMS_Spec( 1, "i != j && j != k", "VALUE = 6", "", "", "" )]
        [ExpectedVC( "true => true" )]
        int Arr3( int[] array, int i, int j, int k )
        {
            array[i] = 1;
            array[j] = 2;
            array[k] = 3;

            return array[i] + array[j] + array[k];
        }

        [XMS_Spec( 1, "true", "VALUE = 10", "", "", "" )]
        //[ExpectedVC( "true => true" )]
        int Arr4( int[] array, int i, int j, int k, int l )
        {
            array[i] = 1;
            array[j] = 2;
            array[k] = 3;
            array[l] = 4;

            return array[i] + array[j] + array[k] + array[l];
        }
    }
    #endregion

    #region Helper types
    public class HelperClass1
    {
        public int n;
        public HelperClass1 child;

        [XMS_Spec( 1, "true", "this.n = 0", "", "", "" )]
        public HelperClass1() { }

        [XMS_Spec( 1, "true", "this.n = n", "", "", "" )]
        public HelperClass1( int n )
        {
            this.n = n;
        }
    }
    #endregion

    #region Delegates
    public class DelegateTest
    {
        public delegate int FooDelegate( int x );

        public int FooExample( int n )
        {
            return n;
        }

        public void Test1()
        {
            FooDelegate foo = new FooDelegate( FooExample );
            int res = foo( 1 );
        }

        public void Test2( FooDelegate FooD, int k )
        {
            int res = FooD( k );
            int res2 = DelegateTest2.Fun( k );
        }

        int theProperty;
        int TheProperty
        {
            get
            {
                return theProperty;
            }
            set
            {
                theProperty = value;
            }
        }
    }

    public class DelegateTest2
    {
        static int F( int x )
        {
            return x+1;
        }

        public static DelegateTest.FooDelegate Fun = new DelegateTest.FooDelegate( F );

    }
    #endregion
}