using System;
using System.Collections;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;

using UWr.XMS.ILReader;

namespace UWr.XMS.Tools.AssemblyAnalyzer
{
	public class InstructionInfo : IComparable
	{
		[XmlAttribute("name")]
		public string name;
		[XmlAttribute("count")]
		public int    count;

		public InstructionInfo() {}
		public InstructionInfo( string name )
		{
			this.name = name;
		}

		#region IComparable Members
		public int CompareTo(object obj)
		{
			if ( obj is InstructionInfo )
				return -count.CompareTo( ((InstructionInfo)obj).count );
			
			return 0;
		}
		#endregion
	}

	[XmlRoot("XMSStatistic")]
	public class InstructionInfoAssembly
	{
		[XmlElement("Instruction", typeof( InstructionInfo ))]
		public ArrayList instructions = new ArrayList();

		public InstructionInfoAssembly() {}
	}

	public delegate void InfoDelegate( string description, int current, int max );
	public class AnalyzerFramework
	{
		private AnalyzerFramework() {}

		public static InstructionInfoAssembly AnalyzeAssembly( Assembly assembly, InfoDelegate info1, InfoDelegate info2 )
		{
			Hashtable ins = new Hashtable();
			Type[] types = assembly.GetTypes();

			for( int i=0; i<types.Length; i++ )
			{
				Type type = types[i];
				info1( type.Name, i, types.Length-1 );

				MethodBase[] methods = type.GetMethods( BindingFlags.Static | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic );
				for ( int j=0; j<methods.Length; j++ )					
				{
					MethodBase mb = methods[j];
					info2( mb.Name, j, methods.Length-1 );

					if ( mb.DeclaringType.Assembly == assembly )
					{
						try
						{
							MethodBodyReader   reader = new MethodBodyReader( mb );
							if ( reader != null )
								foreach ( ILInstruction instruction in reader.Instructions )
								{
									if ( !ins.ContainsKey( instruction.Code.Name ) )
										ins.Add( instruction.Code.Name, new InstructionInfo( instruction.Code.Name ) );
									InstructionInfo ii = (InstructionInfo)ins[instruction.Code.Name];
									ii.count++;
								}
						}
						catch
						{
							continue;
						}
					}
				}				
			}

			InstructionInfoAssembly iia = new InstructionInfoAssembly();
			iia.instructions.AddRange( ins.Values );
			iia.instructions.Sort();

			return iia;
		}
	}
}
