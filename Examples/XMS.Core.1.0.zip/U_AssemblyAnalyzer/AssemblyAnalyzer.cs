using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace UWr.XMS.Tools.AssemblyAnalyzer
{
	public class AssemblyAnalyzer : System.Windows.Forms.Form
	{
		private InstructionInfoAssembly iia = null;

		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem mnuAnalyze;
		private System.Windows.Forms.GroupBox gbProgress;
		private System.Windows.Forms.Label lblType;
		private System.Windows.Forms.Label lblMethod;
		private System.Windows.Forms.ProgressBar pb1;
		private System.Windows.Forms.ProgressBar pb2;
		private System.Windows.Forms.ListView lstItems;
		private System.Windows.Forms.MenuItem mnuSaveAs;
		private System.ComponentModel.Container components = null;

		public AssemblyAnalyzer()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.mnuAnalyze = new System.Windows.Forms.MenuItem();
			this.gbProgress = new System.Windows.Forms.GroupBox();
			this.pb2 = new System.Windows.Forms.ProgressBar();
			this.pb1 = new System.Windows.Forms.ProgressBar();
			this.lblMethod = new System.Windows.Forms.Label();
			this.lblType = new System.Windows.Forms.Label();
			this.lstItems = new System.Windows.Forms.ListView();
			this.mnuSaveAs = new System.Windows.Forms.MenuItem();
			this.gbProgress.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuAnalyze,
																					  this.mnuSaveAs});
			this.menuItem1.Text = "File";
			// 
			// mnuAnalyze
			// 
			this.mnuAnalyze.Index = 0;
			this.mnuAnalyze.Text = "Analyze";
			this.mnuAnalyze.Click += new System.EventHandler(this.mnuAnalyze_Click);
			// 
			// gbProgress
			// 
			this.gbProgress.Controls.Add(this.pb2);
			this.gbProgress.Controls.Add(this.pb1);
			this.gbProgress.Controls.Add(this.lblMethod);
			this.gbProgress.Controls.Add(this.lblType);
			this.gbProgress.Dock = System.Windows.Forms.DockStyle.Top;
			this.gbProgress.Location = new System.Drawing.Point(0, 0);
			this.gbProgress.Name = "gbProgress";
			this.gbProgress.Size = new System.Drawing.Size(428, 72);
			this.gbProgress.TabIndex = 1;
			this.gbProgress.TabStop = false;
			this.gbProgress.Text = "Progress";
			// 
			// pb2
			// 
			this.pb2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pb2.Location = new System.Drawing.Point(264, 44);
			this.pb2.Name = "pb2";
			this.pb2.Size = new System.Drawing.Size(156, 20);
			this.pb2.TabIndex = 3;
			// 
			// pb1
			// 
			this.pb1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pb1.Location = new System.Drawing.Point(264, 20);
			this.pb1.Name = "pb1";
			this.pb1.Size = new System.Drawing.Size(156, 20);
			this.pb1.TabIndex = 2;
			// 
			// lblMethod
			// 
			this.lblMethod.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMethod.Location = new System.Drawing.Point(8, 44);
			this.lblMethod.Name = "lblMethod";
			this.lblMethod.Size = new System.Drawing.Size(252, 20);
			this.lblMethod.TabIndex = 1;
			this.lblMethod.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblType
			// 
			this.lblType.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblType.Location = new System.Drawing.Point(8, 20);
			this.lblType.Name = "lblType";
			this.lblType.Size = new System.Drawing.Size(252, 20);
			this.lblType.TabIndex = 0;
			this.lblType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lstItems
			// 
			this.lstItems.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lstItems.FullRowSelect = true;
			this.lstItems.GridLines = true;
			this.lstItems.Location = new System.Drawing.Point(0, 72);
			this.lstItems.Name = "lstItems";
			this.lstItems.Size = new System.Drawing.Size(428, 226);
			this.lstItems.TabIndex = 2;
			this.lstItems.View = System.Windows.Forms.View.Details;
			// 
			// mnuSaveAs
			// 
			this.mnuSaveAs.Index = 1;
			this.mnuSaveAs.Text = "Save as...";
			this.mnuSaveAs.Click += new System.EventHandler(this.mnuSaveAs_Click);
			// 
			// AssemblyAnalyzer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(428, 298);
			this.Controls.Add(this.lstItems);
			this.Controls.Add(this.gbProgress);
			this.Menu = this.mainMenu;
			this.Name = "AssemblyAnalyzer";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Assembly Analyzer 1.0";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.gbProgress.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void mnuAnalyze_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog of   = new OpenFileDialog();
			of.InitialDirectory = Directory.GetCurrentDirectory();
			of.Filter           = "Pliki wykonywalne (*.exe)|*.exe|Biblioteki (*.dll)|*.dll";

			if ( of.ShowDialog() == DialogResult.OK )
			{
				try
				{
					Assembly  assembly = Assembly.LoadFrom( of.FileName );
					iia = AnalyzerFramework.AnalyzeAssembly( assembly,
						new InfoDelegate( info1 ),
						new InfoDelegate( info2 ) );
					MessageBox.Show( "Analysis complete.", "Info", MessageBoxButtons.OK );

					lstItems.Items.Clear();
					lstItems.Columns.Clear();
					lstItems.Columns.Add( "Instruction", 60, HorizontalAlignment.Left );
					lstItems.Columns.Add( "Count", 60, HorizontalAlignment.Left );
					
					foreach ( InstructionInfo ii in iia.instructions )
					{
						ListViewItem li = lstItems.Items.Add( ii.name );
						li.SubItems.Add( ii.count.ToString() );
					}

					foreach ( ColumnHeader ch in lstItems.Columns )
						ch.Width = -2;
				}
				catch( Exception ex )
				{
					MessageBox.Show( string.Format( "{0}\r\n{1}", ex.Message, ex.StackTrace ) );
					return;
				}
			}
		}

		void info1( string caption, int current, int max )
		{
			this.lblType.Text = caption;
			this.pb1.Maximum  = max;
			this.pb1.Value    = current;
			//this.Refresh();
		}
		void info2( string caption, int current, int max )
		{
			this.lblMethod.Text = caption;
			this.pb2.Maximum    = max;
			this.pb2.Value      = current;
			Application.DoEvents();
		}

		private void mnuSaveAs_Click(object sender, System.EventArgs e)
		{
			if ( iia != null )
				using ( SaveFileDialog sf = new SaveFileDialog() )
				{
					sf.Filter = "Pliki XML (*.xml)|*.xml";
					sf.InitialDirectory = Directory.GetCurrentDirectory();
					sf.CheckPathExists = true;
					sf.OverwritePrompt = true;

					if ( sf.ShowDialog() == DialogResult.OK )
					{
						StreamWriter  sw = new StreamWriter( sf.FileName, false, Encoding.Unicode );
						XmlSerializer xs = new XmlSerializer( typeof(InstructionInfoAssembly) );

						xs.Serialize( sw, iia );

						sw.Close();
					}
				}
		}

	}
}
