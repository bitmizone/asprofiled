using System;
using System.Windows.Forms;

namespace UWr.XMS.Tools.AssemblyAnalyzer
{
	public class CMain
	{
		[STAThread]
		static void Main() 
		{
			Application.Run(new AssemblyAnalyzer());
		}
	}
}
