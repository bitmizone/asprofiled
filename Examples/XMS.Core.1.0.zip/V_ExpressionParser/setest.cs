using System;
using System.Collections;
using System.IO;
using Tools;

using UWr.XMS.VCGen;
using UWr.XMS.VCGen.Lexing;
using UWr.XMS.VCGen.Parsing;

namespace test
{
  public class MainClass {
  public static void Main( string[] args )
  {
    try
    {      
      using ( StreamReader sr = new StreamReader( args[0] ) )
      {
        string line;

        while ( (line = sr.ReadLine() ) != null )
        {
          Console.Write( line );
          
          Parser    p = new syntax( new tokens() );
          SYMBOL ps = p.Parse( line );
          
          if ( ps is SymbExpr )
            Console.WriteLine( string.Format( " : {0}", ps ) );
          else
            Console.WriteLine( " failed!" );
        }
      }      
    }
    catch( CSToolsException ex )
    {
      Console.WriteLine( string.Format( "{0}\r\n\r\n at line {1}, char {2}, string {3}", ex.Message, ex.nLine, ex.nChar, ex.sInput ) );
    }        
    catch( Exception ex )
    {
      Console.WriteLine( string.Format( "{0}\r\n\r\nat\r\n\r\n{1}", ex.Message, ex.StackTrace ) );
    }
  }
  }
}