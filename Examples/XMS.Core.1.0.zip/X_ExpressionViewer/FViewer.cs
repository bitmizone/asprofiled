using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using UWr.XMS.VCGen.Parsing;

namespace X_ExpressionViewer
{
    public partial class FViewer : Form
    {
        public FViewer()
        {
            InitializeComponent();
        }

        private void btGo_Click( object sender, EventArgs e )
        {
            tvExpression.Nodes.Clear();

            SymbExpr Expression;
            if ( SymbExpr.TryParse( txtExpression.Text, out Expression ) )
                BuildSubexpressionTree( Expression, tvExpression.Nodes );
            else
            {
                /* capture the exception */
                try
                {
                    Expression = SymbExpr.Parse( txtExpression.Text );
                }
                catch ( Exception ex )
                {
                    tvExpression.Nodes.Add( new TreeNode( ex.Message ) );
                }
            }
            
        }

        private void BuildSubexpressionTree( SymbExpr Expression, TreeNodeCollection Nodes )
        {
            /* add node */
            TreeNode Node = new TreeNode();
            Node.Text = Expression.ToString();
            Nodes.Add( Node );                    

            /* process subnodes */
            switch ( Expression.ExpType )
            {
                case SymbExpr.ExprType.Bin :

                    Node.Text = string.Format( "{0}, {1}", Expression.BinExpr.op, Expression );

                    BuildSubexpressionTree( Expression.BinExpr.ex1, Node.Nodes );
                    BuildSubexpressionTree( Expression.BinExpr.ex2, Node.Nodes );

                    break;

                case SymbExpr.ExprType.Un:

                    Node.Text = string.Format( "{0}, {1}", Expression.UnExpr.op, Expression );

                    BuildSubexpressionTree( Expression.UnExpr.ex, Node.Nodes );

                    break;

                case SymbExpr.ExprType.Forall:

                    BuildSubexpressionTree( Expression.ForallExpr.ex, Node.Nodes );

                    break;

                case SymbExpr.ExprType.Br:

                    Nodes.Remove( Node );
                    BuildSubexpressionTree( Expression.BrExpr.ex, Nodes );

                    break;
            }
        }
    }
}