C++ Gold Parser Engine (c) 2002-2003 Manuel Astudillo
-----------------------------------------------------

This library is distributed under LGPL license. Please read file src/COPYING for
more details about license terms. Read also WHATSNEW for the latest improvements
for this version.

The   latest     version   of     this   library     can   be     donwload   at:
http://cpp-gpengine.sourceforge.net. In the same  adress it is possible  to find
some more documentation and news.

This gpengine  is a  free work  not supported,  nor involved  in any  way in the
development of Devin Cook's Gold Parser Builder utility. For questions regarding
the builder please use the Gold Parser forums at: 
http://groups.yahoo.com/group/GOLDParser/

For    questions,     comments,    bug     reports    or     feature    requests
regarding cpp-gpengine  please  use   the facilities  available at sourceforge's
webpage.

For personal contact email at: d00mas@efd.lth.se



